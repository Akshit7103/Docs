/**
 * AccessGuard — ONE source of truth for the app's board/case access rules (previously duplicated inline
 * across wiz-dashboard, ai-extraction and ai-dashboard). Consumers call these instead of copy-pasting the
 * role + assignment checks, so the rule can't drift between pages.
 *
 * Rules (unchanged from the inline versions):
 *   - Managers (explicit x_nose_nfotc_bsm.manager role) and platform admins have full access.
 *   - Otherwise an analyst may view a board only for a wizard ASSIGNED to them (canViewWizard), or any of
 *     the AI surfaces only if they still have at least one published assignment (canViewAny).
 */
var AccessGuard = Class.create();
AccessGuard.prototype = {
    initialize: function () {},

    LANDING: '/nfotcbsm?id=bsm_work_drivers',

    /** Platform admin OR an explicitly-granted app manager OR an approved demo operator. Demo operators
     *  (the x_nose_nfotc_bsm.demo_users allow-list) get manager-level VIEW across the app so they can preview the
     *  manager surfaces without an admin/manager grant. NOTE: this is view/access only — ACTING on a cashflow
     *  (confirm / override / write-back) still requires being the assigned analyst (isAssignedAnalyst), which
     *  is unaffected here. The list is a system property only an admin can edit, so this is not arbitrary
     *  escalation. */
    isManagerOrAdmin: function () {
        return gs.hasRole('admin') || this._hasManagerRole() || this.isDemoUser();
    },

    /** Demo operators who get the Manager/Analyst view-as toggle (and manager-level view). Driven by the
     *  x_nose_nfotc_bsm.demo_users system property (comma-separated user_names) so people can be added/removed in
     *  the instance with NO code deploy; falls back to the original test operator if the property is unset. */
    isDemoUser: function () {
        try {
            var me = '' + gs.getUser().getName();
            if (!me) { return false; }
            var list = ('' + (gs.getProperty('x_nose_nfotc_bsm.demo_users', 'akshit.mahajan') || '')).split(',');
            for (var i = 0; i < list.length; i++) { if (('' + list[i]).trim() === me) { return true; } }
        } catch (e) { /* not a demo user */ }
        return false;
    },

    /**
     * Explicitly-granted app-manager role — distinct from a plain platform admin, who "has" every role via
     * gs.hasRole() but was never granted THIS one. Robust on purpose: it scans the granted-role list AND,
     * as a fallback, does a definitive sys_user_has_role lookup (catches group-inherited grants and contexts
     * where getRoles() doesn't surface the scoped role name). Used for both the access gate and the role
     * label so the two can never disagree.
     */
    _hasManagerRole: function () {
        try {
            var roles = gs.getUser().getRoles() || [];
            for (var i = 0; i < roles.length; i++) { if (('' + roles[i]) === 'x_nose_nfotc_bsm.manager') { return true; } }
        } catch (e) { /* fall through to the DB check */ }
        try {
            var gr = new GlideRecord('sys_user_has_role');
            gr.addQuery('user', gs.getUserID());
            gr.addQuery('role.name', 'x_nose_nfotc_bsm.manager');
            gr.setLimit(1);
            gr.query();
            return gr.hasNext();
        } catch (e2) { return false; }
    },

    /** Is this an approved demo operator? Only they get the view-as toggle. Alias of isDemoUser so the label
     *  and the toggle share ONE source. */
    _isTestUser: function () { return this.isDemoUser(); },

    /** The test operator's session view-as preference ('manager' | 'analyst' | ''); empty/other = analyst. */
    _viewAs: function () {
        try { return '' + (gs.getSession().getClientData('nfotc_view_as') || ''); } catch (e) { return ''; }
    },

    /**
     * Human-facing role label for the header chip — the ONE place this is decided (previously five
     * inconsistent inline copies plus seven pages hard-coding 'Analyst'). Precedence Manager > Administrator
     * > Analyst, honoring the test operator's view-as toggle so the demo can preview the Analyst experience.
     * Every page reads data.role from this, so a manager/admin viewing any board sees their real role.
     */
    roleLabel: function () {
        if (this._isTestUser()) { return this._viewAs() === 'manager' ? 'Manager' : 'Analyst'; }
        if (this._hasManagerRole()) { return 'Manager'; }
        if (gs.hasRole('admin')) { return 'Administrator'; }
        return 'Analyst';
    },

    /**
     * Header identity - a clean display name + initials for the console header, tolerant of directory formats.
     * Nomura's LDAP-fed sys_user.name is "Last, First (Dept/Region)" (bsmdev), eval's is "First Last"; the raw
     * value rendered "Mahajan, Akshit (Operations/IN)" with initials "M(". So: drop any (...) / [...] suffix,
     * flip "Last, First" to "First Last", collapse whitespace, title-case. Fallbacks: user_name, then `fallback`.
     * Every header widget reads its name + initials from here, so the rule lives in ONE place.
     */
    userDisplayName: function (fallback) {
        var raw = '' + (gs.getUserDisplayName() || '');
        raw = raw.replace(/\s*\([^)]*\)/g, ' ').replace(/\s*\[[^\]]*\]/g, ' ').trim();
        if (raw.indexOf(',') !== -1) {
            var lf = raw.split(',');                                             // "Last, First Middle"
            raw = (lf.slice(1).join(' ') + ' ' + lf[0]).replace(/\s+/g, ' ').trim();   // -> "First Middle Last"
        }
        if (!raw) { raw = '' + (gs.getUserName() || ''); }
        if (!raw || raw === 'guest') { raw = '' + (fallback || 'User'); }
        return raw.replace(/\s+/g, ' ').replace(/\b\w/g, function (m) { return m.toUpperCase(); });
    },
    userInitials: function (fallback) {
        var parts = this.userDisplayName(fallback).split(' ');
        var first = (parts[0] || '').replace(/[^A-Za-z0-9]/g, '').charAt(0);
        var last = parts.length > 1 ? (parts[parts.length - 1] || '').replace(/[^A-Za-z0-9]/g, '').charAt(0) : '';
        return ((first || ('' + (fallback || 'U')).charAt(0)) + last).toUpperCase();
    },

    _assigned: function (wizGr, uid) {
        var au = [];
        try { au = JSON.parse(wizGr.getValue('assigned_users') || '[]'); } catch (e) { au = []; }
        for (var i = 0; i < au.length; i++) { if (au[i] && au[i].id === uid) { return true; } }
        return false;
    },

    /** Is the CURRENT user an assigned analyst of THIS wizard? (independent of manager/admin role.)
     *  Used to decide the board's READ-ONLY mode: only the assigned analyst may act; a manager/admin who
     *  is not assigned views it read-only (FR-UI-022 — managers can't confirm/override/write-back). */
    isAssignedAnalyst: function (wizId) {
        if (!wizId) { return false; }
        var wg = new GlideRecord('x_nose_nfotc_bsm_wizard');
        if (!wg.get(wizId)) { return false; }
        return this._assigned(wg, gs.getUserID());
    },

    /** May the current user view the board for THIS wizard? (manager/admin, or assigned to it). */
    canViewWizard: function (wizId) {
        if (this.isManagerOrAdmin()) { return true; }
        if (!wizId) { return false; }
        var wg = new GlideRecord('x_nose_nfotc_bsm_wizard');
        if (!wg.get(wizId)) { return false; }
        return this._assigned(wg, gs.getUserID());
    },

    /** May the current user view the AI surfaces at all? (manager/admin, or assigned to >=1 published wizard). */
    canViewAny: function () {
        if (this.isManagerOrAdmin()) { return true; }
        var uid = gs.getUserID();
        var wz = new GlideRecord('x_nose_nfotc_bsm_wizard');
        wz.addQuery('status', 'published');
        wz.query();
        while (wz.next()) { if (this._assigned(wz, uid)) { return true; } }
        return false;
    },

    /**
     * Row-level check for a CASHFLOW record — resolves its owning wizard (via the parent email's
     * wiz_extracted) and delegates to canViewWizard. Used by the cashflow read ACL so an analyst lists
     * only cashflows for a work-driver assigned to them. (Managers/admins see all.)
     */
    canViewCashflow: function (cfGr) {
        if (this.isManagerOrAdmin()) { return true; }
        try {
            var em = new GlideRecord('x_nose_nfotc_bsm_email');
            if (em.get(cfGr.getValue('email'))) { return this.canViewWizard(em.getValue('wiz_extracted')); }
        } catch (e) { /* fail closed */ }
        return false;
    },

    /** May the current user ACT on a cashflow (confirm / override / write-back)? ONLY the assigned analyst
     *  of the owning work-driver — managers/admins can view but not act (FR-UI-022). Resolves the wizard via
     *  the parent email's wiz_extracted. */
    canActOnCashflow: function (cfGr) {
        try {
            var em = new GlideRecord('x_nose_nfotc_bsm_email');
            if (em.get(cfGr.getValue('email'))) { return this.isAssignedAnalyst(em.getValue('wiz_extracted')); }
        } catch (e) { /* fail closed */ }
        return false;
    },

    type: 'AccessGuard',
};
