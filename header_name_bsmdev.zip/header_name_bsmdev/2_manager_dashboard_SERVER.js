/**
 * Manager Dashboard (Service Portal) — the manager's landing page.
 *
 * Nomura-styled console with a left nav, the published work-drivers as selectable chips, three KPI
 * cards (Open / Resolved / Critical), and an "Unactioned items by Analyst" table built from REAL
 * workflow assignments (an analyst's pending = open cashflows in the workflows assigned to them).
 * Manager-only: analysts/admins-without-the-manager-role are redirected away (client guard).
 */
(function () {
    // EXPLICIT role check — gs.hasRole('x_nose_nfotc_bsm.manager') is TRUE for every admin (admins pass all
    // role checks), so we inspect the user's actual granted roles instead (admin is NOT expanded here).
    function hasExplicitRole(roleName) {
        try {
            var roles = gs.getUser().getRoles();
            if (!roles) { return false; }
            for (var i = 0; i < roles.length; i++) { if (('' + roles[i]) === roleName) { return true; } }
        } catch (e) { /* fall through */ }
        return false;
    }

    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('Manager');

    // View-as toggle — for approved demo operators (x_nose_nfotc_bsm.demo_users): switch Manager/Analyst view.
    var isTestUser = new x_nose_nfotc_bsm.AccessGuard().isDemoUser();
    if (isTestUser && input && input.action === 'set_view') {
        gs.getSession().putClientData('nfotc_view_as', input.viewAs === 'manager' ? 'manager' : 'analyst');
    }
    var viewAs = isTestUser ? ('' + (gs.getSession().getClientData('nfotc_view_as') || '')) : '';

    data.isAdmin = gs.hasRole('admin');
    data.isManager = isTestUser ? (viewAs === 'manager') : hasExplicitRole('x_nose_nfotc_bsm.manager');
    data.isTestUser = isTestUser;
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('Manager');

    // ── SERVER-SIDE MANAGER GATE ── the client already redirects non-managers, but the server previously
    // still BUILT and serialized the full manager payload (analyst roster, workloads, KPIs) to anyone. Stop
    // here for genuine analysts (non-manager, non-admin, non-demo) so nothing sensitive is ever sent.
    if (!new x_nose_nfotc_bsm.AccessGuard().isManagerOrAdmin()) {
        data.redirect = '/nfotcbsm?id=bsm_work_drivers';
        data.drivers = []; data.analysts = []; data.kpis = [];
        return;
    }

    var selWiz = (input && input.wiz) || $sp.getParameter('wiz') || '';
    data.selWiz = selWiz;
    data.selName = 'All work drivers';

    // Published work-drivers (chips) + the analyst assignments per workflow.
    data.drivers = [];
    var analystMap = {};    // userSysId -> { name, wiz: { wizId: true } }
    var assignedWiz = {};   // wizId -> true  (published wizards that have >=1 assigned analyst)
    var wz = new GlideRecord('x_nose_nfotc_bsm_wizard');
    wz.addQuery('status', 'published');
    wz.orderBy('name');
    wz.query();
    while (wz.next()) {
        var id = wz.getUniqueValue(), nm = wz.getValue('name') || 'Untitled';
        data.drivers.push({ id: id, name: nm });
        if (id === selWiz) { data.selName = nm; }
        var au = [];
        try { au = JSON.parse(wz.getValue('assigned_users') || '[]'); } catch (e) { au = []; }
        if (au.length) { assignedWiz[id] = true; }   // an item only "awaits analyst action" once the workflow is assigned
        if (selWiz && id !== selWiz) { continue; }   // scope the analyst table to the selected driver
        for (var a = 0; a < au.length; a++) {
            var aid = au[a].id;
            if (!aid) { continue; }
            if (!analystMap[aid]) { analystMap[aid] = { name: au[a].name, wiz: {} }; }
            analystMap[aid].wiz[id] = true;
        }
    }

    // email -> owning wizard (wiz_extracted), so each cashflow can be attributed to a workflow.
    var emailWiz = {};
    var eg = new GlideRecord('x_nose_nfotc_bsm_email');
    eg.query();
    while (eg.next()) { emailWiz[eg.getUniqueValue()] = eg.getValue('wiz_extracted') || ''; }

    var nowMs = new GlideDateTime().getNumericValue();
    function elapsed(created) {
        if (!created) { return '-'; }
        var t = new GlideDateTime(created).getNumericValue();
        var mins = Math.max(0, Math.floor((nowMs - t) / 60000));
        if (mins < 60) { return mins + 'm'; }
        var hrs = Math.floor(mins / 60);
        if (hrs < 24) { return hrs + 'h'; }
        return Math.floor(hrs / 24) + 'd ' + (hrs % 24) + 'h';
    }

    // KPI counts (Open / Resolved / Critical) + per-analyst pending (attributed via workflow assignment).
    var open = 0, resolved = 0, critical = 0;
    var pend = {};   // userSysId -> { pending, oldest:{ref,created} }
    var cf = new GlideRecord('x_nose_nfotc_bsm_cashflow');
    cf.orderBy('sys_created_on');   // oldest first
    cf.query();
    while (cf.next()) {
        var eid = cf.getValue('email');
        if (!emailWiz.hasOwnProperty(eid)) { continue; } // skip ORPHANS — cashflow whose parent email no longer exists
        var wid = emailWiz[eid] || '';
        // Only count items owned by a currently-published, ASSIGNED workflow. This excludes items tagged to
        // a deleted wizard, items never processed by a wizard, and published-but-unassigned workflows — so
        // with no assignment the KPIs read 0, matching the analyst table.
        if (!wid || !assignedWiz[wid]) { continue; }
        if (selWiz && wid !== selWiz) { continue; }
        var res = cf.getValue('ai_resolution');
        var mo = cf.getValue('ai_mo_sent');
        var ms = cf.getValue('ai_match_status');
        if ((res && res !== '') || mo === 'true') { resolved++; continue; }
        open++;
        if (ms === 'no_match' || ms === 'mismatch' || ms === 'amount_mismatch') { critical++; }
        var ref = cf.getValue('ai_reference') || cf.getValue('reference') || '';
        var created = cf.getValue('sys_created_on');
        for (var uid in analystMap) {
            if (analystMap[uid].wiz[wid]) {
                if (!pend[uid]) { pend[uid] = { pending: 0, oldest: null }; }
                pend[uid].pending++;
                if (!pend[uid].oldest) { pend[uid].oldest = { ref: ref, created: created }; }  // oldest-first
            }
        }
    }
    data.kpis = { open: open, resolved: resolved, critical: critical };

    // wizId -> name, so each analyst row can link to the work-driver board(s) they own (read-only).
    var driverName = {};
    for (var di = 0; di < data.drivers.length; di++) { driverName[data.drivers[di].id] = data.drivers[di].name; }

    // Real analyst rows — only analysts assigned to a workflow, with at least one open item.
    data.analysts = [];
    for (var uid2 in analystMap) {
        var p = pend[uid2];
        if (!p || !p.pending) { continue; }
        // The work-driver board(s) this analyst is assigned to — opened by the manager in READ-ONLY (ro=1).
        var drv = [];
        for (var wzid in analystMap[uid2].wiz) {
            drv.push({ id: wzid, name: driverName[wzid] || wzid, url: '/nfotcbsm?id=bsm_nfotc_wiz_dash&wiz=' + wzid + '&ro=1' });
        }
        data.analysts.push({
            name: analystMap[uid2].name,
            pending: p.pending,
            oldestRef: p.oldest ? (p.oldest.ref || '-') : '-',
            elapsed: p.oldest ? elapsed(p.oldest.created) : '-',
            drivers: drv
        });
    }
    data.analysts.sort(function (x, y) { return y.pending - x.pending; });
})();
