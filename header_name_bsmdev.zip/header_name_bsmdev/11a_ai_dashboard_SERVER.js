/**
 * OTC AI Dashboard — RETIRED.
 * This page was a GLOBAL console showing every work-driver's mails (OTC + CSG) via TaggingDashboard.dataAi()
 * with no wizard scope. It is superseded by the per-wizard boards (nfotc_wiz_dash), which are correctly
 * scoped. Nothing links here anymore; any direct hit on /nfotcbsm?id=bsm_ai_dashboard now bounces to the landing
 * page (the client navigates on data.redirect). Kept as a redirect stub so the URL resolves cleanly.
 */
(function () {
    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    // Header identity (name + avatar initials) from the ONE helper - was a hardcoded 'US' in the template.
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('User');
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('User');
    data.redirect = '/nfotcbsm?id=bsm_work_drivers';
    data.stats = []; data.rows = []; data.counterparties = []; data.empty = true;
})();
