/**
 * OTC AI Case Screen — Service Portal widget SERVER script.
 * Full replica of the OTC analyst screen (Extracted -> Compare & Match -> Decide next action, with
 * analyst-feedback writeback), but every extracted value comes from the AI fields (ai_*), the match
 * runs via CompareMatch.buildDataAi, and all analyst-feedback state is stored on the PARALLEL ai_*
 * workflow fields (ai_confirmed / ai_analyst_outcome / ai_review_confirmed / ai_resolution) so the AI
 * path is completely independent of the OTC path. AI extraction logic itself is untouched.
 */
(function () {
    // ── ACCESS GUARD (centralised: x_nose_nfotc_bsm.AccessGuard) ──
    // A non-manager/admin analyst may open a case ONLY while they still have at least one PUBLISHED
    // work-driver assigned. Re-evaluated on every request, so once the manager deletes the work-driver or
    // unassigns the analyst, the next load/refresh bounces them to the landing page (client navigates away).
    data.redirect = '';
    if (!new x_nose_nfotc_bsm.AccessGuard().canViewAny()) { data.redirect = '/nfotcbsm?id=bsm_work_drivers'; }
    if (data.redirect) { data.empty = true; return; }

    // READ-ONLY (FR-UI-022): only the ASSIGNED analyst of the cashflow's work-driver may act (confirm /
    // override / write-back). A manager/admin — or anyone arriving from a read-only board (?ro=1) — views it
    // read-only: every state-changing action is gated server-side below, and the buttons are hidden in the UI.
    var _ag = new x_nose_nfotc_bsm.AccessGuard();
    data.role = _ag.roleLabel();
    // Header identity (name + avatar initials) from the ONE helper - was a hardcoded 'US' in the template.
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('User');
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('User');
    function _canActCf(cfSysId) { if (!cfSysId) { return false; } var _g = new GlideRecord('x_nose_nfotc_bsm_cashflow'); return _g.get('' + cfSysId) ? _ag.canActOnCashflow(_g) : false; }
    var _roParam = ('' + ($sp.getParameter('ro') || (input && input.ro) || '')) === '1';
    // $sp.getParameter is only reliable on the initial GET; on a server.update() POST the URL params are
    // gone, so fall back to the persisted client value (data.cfParam / data.ro) — otherwise readOnly would
    // flip to true after every Save/Confirm and hide all controls. Same fallback used at line ~295.
    var _cfForRo = $sp.getParameter('cf') || (input && input.cfParam) || '';
    data.readOnly = _roParam || !_canActCf(_cfForRo);
    data.ro = _roParam ? '1' : '';   // persist so the fallback above survives a server.update() POST

    var ex = new x_nose_nfotc_bsm.EmlFieldExtractor();
    function setIf(gr, col, v) { if (v !== null && v !== undefined) { gr.setValue(col, '' + v); } }
    function vdDisp(v) { var m = ('' + (v || '')).match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? (m[3] + '-' + m[2] + '-' + m[1]) : ('' + (v || '')); }
    function vdIso(v) { v = '' + (v || ''); if (/^\d{4}-\d{2}-\d{2}$/.test(v)) { return v; } var m = v.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/); return m ? (m[3] + '-' + ('0' + m[1]).slice(-2) + '-' + ('0' + m[2]).slice(-2)) : v; }
    function fmtReceived(raw) {
        raw = '' + (raw || '');
        var m = raw.match(/(\d{1,2})\s+([A-Za-z]{3})[A-Za-z]*\s+(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
        if (!m) { return raw; }
        var mo = { jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06', jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12' }[m[2].toLowerCase()] || '01';
        return ('0' + m[1]).slice(-2) + '-' + mo + '-' + m[3] + ' ' + ('0' + m[4]).slice(-2) + ':' + m[5] + ':' + (m[6] || '00');
    }
    function extractEmail(s) {
        s = '' + (s || '');
        var m = s.match(/<([^>]+)>/); if (m) { return m[1].trim(); }
        m = s.match(/[\w.+-]+@[\w.-]+\.\w+/); return m ? m[0] : '';
    }
    function fmtAmt(v) {
        var n = parseFloat(('' + (v || '')).replace(/,/g, ''));
        if (isNaN(n)) { return '' + (v || '-'); }
        var p = n.toFixed(2).split('.');
        p[0] = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return p.join('.');
    }
    // Never-negative amount + direction double-flip rule — delegated to the SHARED AmountDirection Script
    // Include so the case screen and the board (TaggingDashboard) agree. Fixes the old inline divergences:
    // free-text directions ("COU RECEIVE") are now normalised before flipping, and an empty direction no
    // longer becomes a '-' sentinel. The AI's raw negative is accepted on extraction ("let it be"); this
    // only governs display + what we persist on an analyst action.
    var _adir = new x_nose_nfotc_bsm.AmountDirection();
    function flipDir(d) { return _adir.flip(d); }
    function amtIsNeg(a) { return _adir.isNeg(a); }
    function amtAbs(a) { return _adir.absAmt(a); }
    function dispDir(amt, dir) { return _adir.dispDir(amt, dir); }
    function drow(label, val) { return '  ' + (label + '                    ').slice(0, 18) + ('' + (val === '' || val == null ? '-' : val)); }
    function detailBlock(ref, ccy, amt, dir, vd) {
        return drow('Trade reference', ref) + '\n' + drow('Currency', ccy) + '\n' +
            drow('Amount', fmtAmt(amt)) + '\n' + drow('Direction', dir) + '\n' + drow('Value date', vd);
    }

    // Step 3 draft — DRIVEN by the write-back action the manager configured for this outcome in the
    // onboarding wizard (Send to NEWS / Reply to Counterparty / Reply to Middle Office). Falls back to a
    // Middle Office referral when nothing is configured. The analyst still resolves with the Resolved
    // buttons; the write-back "send" is the configured side action.
    function buildDraft(action) {
        var ref = data.reference || '(no reference)';
        var ccy = data.currency || '', amt = data.amount || '', vd = data.value_date || '';
        var cp = data.counterparty || 'Counterparty';
        var subj = ref + ' (' + ccy + ', value ' + vd + ')';
        var bk = (data.cmp && data.cmp.booking) ? data.cmp.booking : null;
        var diffs = (data.cmp && data.cmp.banner) ? data.cmp.banner.diffs.concat(data.cmp.banner.miss).join(', ') : '';
        var cpBlk = detailBlock(ref, ccy, amt, data.direction, vd);
        var bkBlk = bk ? detailBlock(bk.bank_trade_ref || bk.reference || '-', bk.currency || ccy, bk.amount, bk.direction || data.direction, bk.value_date || vd) : '  (no matching booking found in our systems)';
        var lead = diffs
            ? ('The counterparty confirmation and our booking differ on the field(s): ' + diffs + '.')
            : (bk ? 'The counterparty confirmation and our booking agree on every field.'
                  : 'No matching booking was found in our systems for the cash flow below.');
        var tail = '\n\nCounterparty: ' + cp + '\nSource email: ' + data.ref + '\n\nCounterparty submitted:\n' + cpBlk + '\n\nBooked by the bank:\n' + bkBlk + '\n\nRegards,\nSettlements';

        // `action` (passed in) is ONE of the manager-configured write-back actions for this outcome
        // (Send to NEWS / Reply to Counterparty / Reply to Middle Office). May be '' when none configured.
        action = '' + (action || '');
        var senderEmail = gr.getValue('mail_from') || (cp + ' Settlements');

        // Default: Middle Office referral (no config, or a Middle Office action).
        // channel: 'email' = an actual message to a person (To/Subject/Body draft). 'system' = a
        // system write-back with NO mail intimation (just a status line) — used for NEWS.
        var d = {
            action: action, channel: 'email', title: 'Refer to Middle Office', to: 'middleoffice@abc.com',
            subject: 'Referral: Trade confirmation — ' + subj, body: lead + tail,
            sendLabel: 'Send to Middle Office', sentLabel: 'Sent to Middle Office'
        };
        if (/news/i.test(action)) {
            // NEWS is a SYSTEM write-back (the booking system), not an email — no mail intimation.
            d.channel = 'system'; d.title = 'Write-back to NEWS'; d.to = ''; d.subject = '';
            d.body = (bk && !diffs)
                ? 'Counterparty confirmation and our booking agree on every field. The confirmed settlement will be written back to NEWS — no email is sent.'
                : 'The confirmed settlement will be written back to NEWS — no email is sent.';
            d.sendLabel = 'Send to NEWS'; d.sentLabel = 'Sent to NEWS';
        } else if (/counterparty/i.test(action)) {
            d.title = 'Reply to Counterparty'; d.to = senderEmail; d.subject = 'Re: Trade confirmation — ' + subj;
            d.body = 'Hi ' + cp + ',\n\n' + lead + tail;
            d.sendLabel = 'Reply to Counterparty'; d.sentLabel = 'Reply sent to counterparty';
        } else if (/middle office/i.test(action)) {
            d.title = /reply/i.test(action) ? 'Reply to Middle Office' : 'Refer to Middle Office';
            d.sendLabel = /reply/i.test(action) ? 'Reply to Middle Office' : 'Send to Middle Office';
            d.sentLabel = /reply/i.test(action) ? 'Reply sent to Middle Office' : 'Sent to Middle Office';
        }
        // Embed the ORIGINAL inbound email underneath the reply — a real reply quotes the source message.
        // Applies to any EMAIL channel (Counterparty / Middle Office); the NEWS system write-back has no
        // email, so it is skipped. Reply on top, quoted original below (standard email reply format).
        if (d.channel === 'email') {
            var m = data.mail || {};
            if (m.body || m.subject) {
                d.body += '\n\n----------------- Original Message -----------------\n' +
                          'From:    ' + (m.from || '') + '\n' +
                          'To:      ' + (m.to || '') + '\n' +
                          (m.received ? ('Sent:    ' + m.received + '\n') : '') +
                          'Subject: ' + (m.subject || '') + '\n' +
                          '----------------------------------------------------\n\n' +
                          (m.body || '');
            }
        }
        return d;
    }

    // ---- Audit trail: append-only capture of analyst actions + AI inferences (BRD §Audit, FSD §15) ----
    var AUD = new x_nose_nfotc_bsm.AuditTrail();
    function auditCf(cfGr, eventType, opts) {
        opts = opts || {};
        var emId = cfGr.getValue('email'), mailId = '', cp = '';
        var em = new GlideRecord('x_nose_nfotc_bsm_email');
        if (em.get(emId)) { mailId = em.getValue('name'); cp = em.getValue('counterparty_name'); }
        opts.entityType = 'cashflow';
        opts.entityId = cfGr.getUniqueValue();
        opts.emailId = emId;
        opts.cashflowId = cfGr.getUniqueValue();
        opts.mailId = mailId;
        opts.counterparty = cp;
        AUD.log(eventType, opts);
    }

    // Save action: persist the edited AI fields back onto the cashflow (ai_* only — never the OTC fields).
    if (input && input.action === 'save' && input.cfSysId && _canActCf(input.cfSysId)) {
        if (input.cfSysId) {
            var cfg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
            if (cfg.get(input.cfSysId)) {
                // Counterparty is DERIVED (not AI) and read-only, so it is never written here. Compare
                // each incoming value to the stored one first, so a corrected field is audited as an
                // override (original AI value vs analyst-corrected value) per FSD override-transparency.
                var fmap = [
                    ['ai_nomura_entity', 'Nomura Entity', input.nomuraEntity],
                    ['ai_reference', 'Trade Reference', input.reference],
                    ['ai_product', 'Product', input.product],
                    ['ai_currency', 'Currency', input.currency],
                    ['ai_trade_date', 'Trade Date', vdIso(input.tradeDate)],
                    ['ai_value_date', 'Value Date', vdIso(input.value_date)],
                    ['ai_ssi_bank', 'SSI Bank / BIC', input.ssiBank],
                    ['ai_ssi_account', 'SSI Account', input.ssiAccount],
                    ['ai_ssi_beneficiary', 'SSI Beneficiary / BIC', input.ssiBeneficiary],
                    ['ai_ssi_intermediary', 'SSI Intermediary', input.ssiIntermediary]
                ];
                var overrides = [];
                for (var fi = 0; fi < fmap.length; fi++) {
                    var col = fmap[fi][0], lbl = fmap[fi][1], nv = fmap[fi][2];
                    if (nv === undefined || nv === null) { continue; }
                    var ov = cfg.getValue(col) || '';
                    if (('' + nv) !== ('' + ov)) { overrides.push({ label: lbl, before: ov, after: '' + nv }); }
                    setIf(cfg, col, nv);
                }
                // Amount + Direction are handled as a PAIR against the DISPLAYED (normalized) values the
                // analyst saw: the card shows |amount| + the double-flipped direction when the stored amount
                // is negative. Persist the normalized pair (never negative, net direction) so it stays stable
                // on re-open; audit only when the analyst genuinely changed what they saw.
                var _stAmtRaw = cfg.getValue('ai_amount'), _stDirRaw = cfg.getValue('ai_direction');
                var _stAmtDisp = amtAbs(_stAmtRaw), _stDirDisp = dispDir(_stAmtRaw, _stDirRaw);
                if (input.amount !== undefined && input.amount !== null) {
                    var _newAmt = amtAbs(input.amount);
                    // Compare against, and audit, the value the analyst actually SAW (the displayed/normalized
                    // one) — not the raw stored value — so we never log a spurious "X -> X" override.
                    if (('' + _newAmt) !== ('' + _stAmtDisp)) { overrides.push({ label: 'Amount', before: _stAmtDisp, after: _newAmt }); }
                    cfg.setValue('ai_amount', '' + _newAmt);
                }
                if (input.direction !== undefined && input.direction !== null) {
                    if (('' + input.direction) !== ('' + _stDirDisp)) { overrides.push({ label: 'Direction', before: _stDirDisp, after: '' + input.direction }); }
                    cfg.setValue('ai_direction', '' + input.direction);
                }
                cfg.update();
                for (var oi = 0; oi < overrides.length; oi++) {
                    var ovr = overrides[oi];
                    auditCf(cfg, 'extraction.overridden', {
                        summary: 'Analyst corrected ' + ovr.label,
                        fieldName: ovr.label, aiValue: ovr.before, analystValue: ovr.after
                    });
                }
            }
        }
        // Counterparty is email-level (derived from the sender directory) and is the value the matcher
        // reads. Allow the analyst to OVERRIDE it here. AUTHORIZATION: resolve the email from the (already
        // access-checked) cashflow — NEVER from a client-supplied email id — so an analyst can't overwrite
        // another wizard's email counterparty by posting a foreign `id`.
        if (input.counterparty !== undefined && input.counterparty !== null && input.cfSysId) {
            var acg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
            if (acg.get(input.cfSysId)) {
                var ecp = new GlideRecord('x_nose_nfotc_bsm_email');
                if (ecp.get(acg.getValue('email'))) {
                    var oldCp = ecp.getValue('counterparty_name') || '';
                    if (('' + input.counterparty) !== ('' + oldCp)) {
                        ecp.setValue('counterparty_name', '' + input.counterparty);
                        ecp.update();
                        auditCf(acg, 'extraction.overridden', {
                            summary: 'Analyst corrected Counterparty',
                            fieldName: 'Counterparty', aiValue: oldCp, analystValue: '' + input.counterparty
                        });
                    }
                }
            }
        }
        data.saved = true;
    }

    // Confirm THIS cashflow's AI extraction (independent of OTC).
    if (input && input.action === 'confirm' && input.cfSysId && _canActCf(input.cfSysId)) {
        var ccg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (ccg.get(input.cfSysId)) {
            // Normalize the pair on confirm so the matched cashflow is never negative (|amount| + net
            // direction) — matches what the analyst confirmed on screen. AUDIT the normalisation (raw ->
            // normalised) so the record mutation is traceable, not silent (the raw AI value is also on the
            // original cashflow.extracted event).
            var _cAmt = ccg.getValue('ai_amount'), _cDir = ccg.getValue('ai_direction');
            if (amtIsNeg(_cAmt)) {
                var _nAmt = amtAbs(_cAmt), _nDir = dispDir(_cAmt, _cDir);
                ccg.setValue('ai_amount', _nAmt);
                ccg.setValue('ai_direction', _nDir);
                auditCf(ccg, 'extraction.normalized', {
                    summary: 'Normalized negative AI amount to bank convention (|amount| + net direction)',
                    aiValue: _cAmt + ' / ' + _cDir, analystValue: _nAmt + ' / ' + _nDir
                });
            }
            ccg.setValue('ai_confirmed', 'true'); ccg.update();
            auditCf(ccg, 'extraction.confirmed', {
                summary: 'Analyst confirmed the extracted fields',
                ai: { amount: ccg.getValue('ai_amount'), currency: ccg.getValue('ai_currency'), value_date: ccg.getValue('ai_value_date'), direction: ccg.getValue('ai_direction') }
            });
        }
    }

    // Analyst outcome writeback (HITL) — ai_* workflow fields only.
    if (input && input.action === 'outcome' && input.cfSysId && input.outcomeChoice && _canActCf(input.cfSysId)) {
        var og = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (og.get(input.cfSysId)) { og.setValue('ai_analyst_outcome', input.outcomeChoice); og.setValue('ai_review_confirmed', ''); og.setValue('ai_resolution', ''); og.setValue('ai_mo_sent', ''); og.update(); }
    }
    if (input && input.action === 'reset_outcome' && input.cfSysId && _canActCf(input.cfSysId)) {
        var rg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (rg.get(input.cfSysId)) { rg.setValue('ai_analyst_outcome', ''); rg.setValue('ai_review_confirmed', ''); rg.setValue('ai_resolution', ''); rg.setValue('ai_mo_sent', ''); rg.update(); }
    }
    if (input && input.action === 'confirm_review' && input.cfSysId && _canActCf(input.cfSysId)) {
        var cvg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (cvg.get(input.cfSysId)) {
            if (input.outcomeChoice) { cvg.setValue('ai_analyst_outcome', input.outcomeChoice); }
            cvg.setValue('ai_review_confirmed', 'true');
            cvg.update();
            auditCf(cvg, 'match.confirmed', { summary: 'Analyst confirmed the match outcome: ' + (cvg.getValue('ai_analyst_outcome') || ''), analystValue: cvg.getValue('ai_analyst_outcome') });
        }
    }
    // Analyst SELECTS which candidate booking to compare against — the selection (not the matcher's
    // best) drives the outcome. Matched if the chosen booking agrees on every field, else Mismatch.
    if (input && input.action === 'select_candidate' && input.cfSysId && input.candKey && _canActCf(input.cfSysId)) {
        var scg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (scg.get(input.cfSysId)) {
            var cmpSel = new x_nose_nfotc_bsm.CompareMatch().buildDataAi(input.cfSysId, '', input.candKey);
            var selOutcome = (cmpSel && cmpSel.systemOutcome === 'matched') ? 'matched' : 'mismatch';
            scg.setValue('ai_selected_booking', input.candKey);
            scg.setValue('ai_analyst_outcome', selOutcome);
            scg.setValue('ai_review_confirmed', ''); scg.setValue('ai_resolution', ''); scg.setValue('ai_mo_sent', '');
            scg.update();
            var topRef = '', selConf = '';
            var cl = (cmpSel && cmpSel.candidatesList) || [];
            for (var ci = 0; ci < cl.length; ci++) { if (cl[ci].best) { topRef = cl[ci].bankRef; } if (cl[ci].key === input.candKey) { selConf = cl[ci].confidence; } }
            auditCf(scg, 'match.selected', {
                summary: 'Selected booking ' + input.candKey + ' at ' + (cmpSel ? cmpSel.tierLabel : '') + ' — ' + selOutcome,
                aiValue: topRef, analystValue: input.candKey,
                ai: { tier: cmpSel ? cmpSel.tier : 0, tierLabel: cmpSel ? cmpSel.tierLabel : '', candidate: input.candKey, confidence: selConf, outcome: selOutcome, diffs: cmpSel ? cmpSel.diffCount : 0, candidates: cl.length }
            });
        }
    }
    // Analyst declares that none of the candidates match -> no-match path.
    if (input && input.action === 'mark_no_match' && input.cfSysId && _canActCf(input.cfSysId)) {
        var nmg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (nmg.get(input.cfSysId)) {
            nmg.setValue('ai_selected_booking', 'none');
            nmg.setValue('ai_analyst_outcome', 'no_match');
            nmg.setValue('ai_review_confirmed', ''); nmg.setValue('ai_resolution', ''); nmg.setValue('ai_mo_sent', '');
            nmg.update();
            auditCf(nmg, 'match.no_match', { summary: 'Analyst marked the cashflow as no match', analystValue: 'no_match' });
        }
    }
    // Step 3 resolution — the analyst picks one; this is what the dashboard Workflow Status shows.
    if (input && input.action === 'resolve_matched' && input.cfSysId && _canActCf(input.cfSysId)) {
        var rm = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (rm.get(input.cfSysId)) { rm.setValue('ai_resolution', 'resolved_matched'); rm.update(); auditCf(rm, 'writeback', { summary: 'Resolved — Matched (sent to NEWS)', analystValue: 'resolved_matched' }); }
    }
    if (input && input.action === 'resolve_unmatched' && input.cfSysId && _canActCf(input.cfSysId)) {
        var ru = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (ru.get(input.cfSysId)) { ru.setValue('ai_resolution', 'resolved_unmatched'); ru.update(); auditCf(ru, 'writeback', { summary: 'Resolved — Unmatched', analystValue: 'resolved_unmatched' }); }
    }
    // Optional side action — records a local "sent" marker only; deliberately does NOT touch
    // ai_resolution, so the dashboard Workflow Status is unaffected by sending to Middle Office.
    if (input && input.action === 'send_mo' && input.cfSysId && _canActCf(input.cfSysId)) {
        var sd = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        var wbLabel = '' + (input.sendLabel || 'Send to Middle Office');
        if (sd.get(input.cfSysId)) { sd.setValue('ai_mo_sent', 'true'); sd.update(); auditCf(sd, 'writeback.mo', { summary: 'Write-back: ' + wbLabel, analystValue: wbLabel }); }
    }

    // Which record to show: ?cf -> parent email; ?eml -> email; else latest relevant.
    var cfParam = $sp.getParameter('cf') || (input && input.cfParam) || '';
    var emlParam = $sp.getParameter('eml') || (input && input.emlParam) || '';
    var emailFromCf = '';
    if (cfParam) { var cfr = new GlideRecord('x_nose_nfotc_bsm_cashflow'); if (cfr.get(cfParam)) { emailFromCf = cfr.getValue('email'); } }
    var wantId = (input && input.id) || emailFromCf || emlParam || '';
    var gr = new GlideRecord('x_nose_nfotc_bsm_email');
    var found = wantId ? gr.get(wantId) : false;
    if (!found) {
        var q = new GlideRecord('x_nose_nfotc_bsm_email');
        q.addQuery('classification', 'relevant');
        q.orderByDesc('sys_created_on'); q.setLimit(1); q.query();
        if (q.next()) { gr = q; } else { data.empty = true; return; }
    }
    // PER-RECORD VIEW GUARD (compare/audit do the same): the caller must be able to view THIS mail's owning
    // work-driver (wiz_extracted||wiz_assigned). canViewAny() above only proves they're SOME analyst; without
    // this, a hand-typed ?cf=/?eml=/picker id — or the "latest relevant" fallback — exposes another wizard's
    // economics + SSI. Managers/admins pass.
    if (!_ag.canViewWizard('' + (gr.getValue('wiz_extracted') || gr.getValue('wiz_assigned')))) {
        data.redirect = '/nfotcbsm?id=bsm_work_drivers'; data.empty = true; return;
    }

    data.empty = false;
    data.id = gr.getUniqueValue();
    data.ref = ('' + (gr.getValue('name') || '')).replace(/\.eml$/i, '') || '(no id)';

    // Resolve the clicked cashflow (or the email's first) and read the AI-extracted fields.
    var cfRec = null;
    if (cfParam) { var cfg2 = new GlideRecord('x_nose_nfotc_bsm_cashflow'); if (cfg2.get(cfParam) && cfg2.getValue('email') === gr.getUniqueValue()) { cfRec = cfg2; } }
    if (!cfRec) { var f1 = new GlideRecord('x_nose_nfotc_bsm_cashflow'); f1.addQuery('email', gr.getUniqueValue()); f1.orderBy('flow_index'); f1.setLimit(1); f1.query(); if (f1.next()) { cfRec = f1; } }
    data.cfSysId = cfRec ? cfRec.getUniqueValue() : '';
    // AI source-snippet provenance for THIS cashflow — drives the exact email-body highlighting + the
    // dynamic legend on the case screen (no client-side string-guessing). null when not yet re-extracted.
    data.sources = null;
    try { data.sources = JSON.parse((cfRec ? cfRec.getValue('ai_sources') : '') || 'null'); } catch (eSrc) { data.sources = null; }
    data.analystOutcome = cfRec ? (cfRec.getValue('ai_analyst_outcome') || '') : '';
    data.reviewConfirmed = cfRec ? (cfRec.getValue('ai_review_confirmed') === 'true') : false;
    // Counterparty is DERIVED from the sender via the counterparty directory (email-level), same as OTC.
    data.counterparty = gr.getValue('counterparty_name');
    data.reference = cfRec ? cfRec.getValue('ai_reference') : gr.getValue('ai_reference');
    data.currency = cfRec ? cfRec.getValue('ai_currency') : gr.getValue('ai_currency');
    // Never surface a negative amount: show |amount|, and double-flip the direction when it was negative.
    var _rawAmt = cfRec ? cfRec.getValue('ai_amount') : gr.getValue('ai_amount');
    var _rawDir = cfRec ? cfRec.getValue('ai_direction') : gr.getValue('ai_direction');
    data.amount = amtAbs(_rawAmt);
    data.direction = dispDir(_rawAmt, _rawDir);
    data.value_date = cfRec ? cfRec.getValue('ai_value_date') : gr.getValue('ai_value_date');   // ISO YYYY-MM-DD
    // The remaining BRD/FSD fields (AI-extracted, per cashflow).
    data.nomuraEntity = cfRec ? cfRec.getValue('ai_nomura_entity') : '';
    data.product = cfRec ? cfRec.getValue('ai_product') : '';
    data.tradeDate = cfRec ? cfRec.getValue('ai_trade_date') : '';   // ISO YYYY-MM-DD
    data.ssiBank = cfRec ? cfRec.getValue('ai_ssi_bank') : '';
    data.ssiAccount = cfRec ? cfRec.getValue('ai_ssi_account') : '';
    data.ssiBeneficiary = cfRec ? cfRec.getValue('ai_ssi_beneficiary') : '';
    data.ssiIntermediary = cfRec ? cfRec.getValue('ai_ssi_intermediary') : '';
    data.confirmed = cfRec ? (cfRec.getValue('ai_confirmed') === 'true') : false;

    // Which fields to DISPLAY = the owning wizard's configured fields (the 4 mandatory + counterparty are
    // always shown; optional fields the wizard did NOT configure are hidden). Default = show all (for
    // cashflows not produced by a wizard).
    data.show = { counterparty: true, value_date: true, amount: true, currency: true, direction: true, reference: true, nomuraEntity: true, product: true, tradeDate: true, ssiBank: true, ssiAccount: true, ssiBeneficiary: true, ssiIntermediary: true };
    var showWiz = gr.getValue('wiz_extracted') || '';
    if (showWiz) {
        var wgShow = new GlideRecord('x_nose_nfotc_bsm_wizard');
        if (wgShow.get(showWiz)) {
            var fldsShow = [];
            try { fldsShow = JSON.parse(wgShow.getValue('input_fields') || '[]'); } catch (eShow) { fldsShow = []; }
            if (fldsShow.length) {
                var FKEY = { 'value date': 'value_date', 'amount': 'amount', 'currency': 'currency', 'direction': 'direction', 'trade reference': 'reference', 'nomura entity': 'nomuraEntity', 'product': 'product', 'trade date': 'tradeDate', 'ssi bank / bic': 'ssiBank', 'ssi account': 'ssiAccount', 'ssi beneficiary / bic': 'ssiBeneficiary', 'ssi intermediary': 'ssiIntermediary' };
                var show = { counterparty: true, value_date: true, amount: true, currency: true, direction: true };
                for (var si = 0; si < fldsShow.length; si++) { var sk = FKEY[('' + (fldsShow[si].name || '')).toLowerCase()]; if (sk) { show[sk] = true; } }
                data.show = show;
            }
        }
    }

    // Write-back actions configured in the owning wizard (per Compare & Match outcome) — surfaced so the
    // analyst sees what the workflow does for this cashflow's outcome (Matched / Mismatch / No Match).
    data.wb = { matched: [], mismatch: [], no_match: [] };
    if (showWiz) {
        var wgWb = new GlideRecord('x_nose_nfotc_bsm_wizard');
        if (wgWb.get(showWiz)) {
            var wbCfg = [];
            try { wbCfg = JSON.parse(wgWb.getValue('writeback') || '[]'); } catch (eWb) { wbCfg = []; }
            for (var wi = 0; wi < wbCfg.length; wi++) {
                var scen = ('' + (wbCfg[wi].scenario || '')).toLowerCase();
                var wkey = (scen.indexOf('mismatch') > -1) ? 'mismatch' : (scen.indexOf('no') > -1 ? 'no_match' : (scen.indexOf('match') > -1 ? 'matched' : ''));
                if (wkey) { data.wb[wkey] = (wbCfg[wi].actions instanceof Array) ? wbCfg[wi].actions : (wbCfg[wi].action ? [wbCfg[wi].action] : []); }
            }
        }
    }
    data.cfParam = cfParam;
    data.emlParam = emlParam;

    // Cashflow navigator (multi-trade mails).
    data.cfList = [];
    var lcf = new GlideRecord('x_nose_nfotc_bsm_cashflow');
    lcf.addQuery('email', gr.getUniqueValue());
    lcf.orderBy('flow_index');
    lcf.query();
    while (lcf.next()) { data.cfList.push(lcf.getUniqueValue()); }
    data.cfTotal = data.cfList.length;
    data.cfIndex = 0;
    for (var ni = 0; ni < data.cfList.length; ni++) { if (data.cfList[ni] === data.cfSysId) { data.cfIndex = ni + 1; break; } }

    // Mail contents from the raw .eml.
    data.mail = { to: '', from: '', cc: '', subject: '', body: '', attachment: '', received: '' };
    data.emlAttId = '';
    var attNames = [];
    var ag = new GlideRecord('sys_attachment');
    ag.addQuery('table_name', 'x_nose_nfotc_bsm_email');
    ag.addQuery('table_sys_id', gr.getUniqueValue());
    ag.orderBy('sys_created_on');
    ag.query();
    while (ag.next()) {
        var ctype = ag.getValue('content_type') || '';
        var fname = ag.getValue('file_name') || '';
        if (!data.emlAttId && (ctype === 'message/rfc822' || /\.eml$/i.test(fname))) {
            data.emlAttId = ag.getUniqueValue();
        } else {
            attNames.push(fname);
        }
    }
    if (data.emlAttId) {
        var m = ex.mailContents(data.emlAttId) || {};
        data.mail.to = m.to || ''; data.mail.from = m.from || ''; data.mail.cc = m.cc || '';
        data.mail.subject = m.subject || ''; data.mail.body = m.body || '';
        data.mail.received = fmtReceived(m.date);
    } else {
        // No raw .eml (e.g. seeded demo data) — fall back to the stored mail_* fields on the email.
        data.mail.to = gr.getValue('mail_to') || '';
        data.mail.from = gr.getValue('mail_from') || '';
        data.mail.subject = gr.getValue('mail_subject') || '';
        data.mail.body = gr.getValue('mail_body') || '';
    }
    data.mail.attachment = attNames.join(', ');

    // ---- Extraction confidence (grounding + validation per field) ----
    // Ground against the full text the AI read (body + parsed spreadsheet grid), rebuilt cheaply
    // (no AI call). Falls back to the body if the .eml can't be re-parsed.
    var confContent = data.mail.body || '';
    try {
        if (data.emlAttId) {
            var dxc = new x_nose_nfotc_bsm.DemoExtractor().run(data.emlAttId, gr.getUniqueValue(), false);
            if (dxc && dxc.aiContent) { confContent = dxc.aiContent; }
        }
    } catch (ecc) { /* fall back to body */ }
    data.conf = new x_nose_nfotc_bsm.ExtractionConfidence().score({
        counterparty: data.counterparty, nomuraEntity: data.nomuraEntity, product: data.product,
        reference: data.reference, tradeDate: data.tradeDate, valueDate: data.value_date,
        amount: data.amount, currency: data.currency, direction: data.direction,
        ssiBank: data.ssiBank, ssiAccount: data.ssiAccount, ssiBeneficiary: data.ssiBeneficiary, ssiIntermediary: data.ssiIntermediary
    }, confContent);

    // Back link → the SCOPED wizard board this case belongs to (NOT the global ai_dashboard, which lists
    // EVERY work-driver's mails, incl. CSG). Owning wizard = the mail's wiz_extracted / wiz_assigned; fall
    // back to the session's current board, then the landing page. This is what made "come back" show CSG.
    var _ownWiz = gr.getValue('wiz_extracted') || gr.getValue('wiz_assigned') || ('' + (gs.getSession().getClientData('nfotc_wiz_current') || ''));
    data.dashUrl = _ownWiz ? ('/nfotcbsm?id=bsm_nfotc_wiz_dash&wiz=' + _ownWiz) : '/nfotcbsm?id=bsm_work_drivers';

    // Step 2 (Compare & Match) — only after the analyst confirms the AI extraction. Uses the AI values.
    data.selectedRef = cfRec ? (cfRec.getValue('ai_selected_booking') || '') : '';
    data.cmp = null;
    if (data.confirmed) {
        var cm = new x_nose_nfotc_bsm.CompareMatch();
        data.cmp = data.cfSysId ? cm.buildDataAi(data.cfSysId, '', data.selectedRef) : cm.buildDataAi('', gr.getUniqueValue(), data.selectedRef);
    }
    data.effectiveOutcome = data.analystOutcome || (data.cmp ? data.cmp.systemOutcome : '');
    data.resolution = cfRec ? (cfRec.getValue('ai_resolution') || '') : '';
    data.moSent = cfRec ? (cfRec.getValue('ai_mo_sent') === 'true') : false;
    // One draft PER manager-configured write-back action for this outcome (the analyst picks which to send).
    // If none configured, fall back to a single default draft (Middle Office referral, as before).
    data.drafts = [];
    if (data.confirmed && data.cmp && data.effectiveOutcome) {
        var _wbActs = (data.wb && data.wb[data.effectiveOutcome]) ? data.wb[data.effectiveOutcome] : [];
        if (_wbActs && _wbActs.length) { for (var _dfi = 0; _dfi < _wbActs.length; _dfi++) { data.drafts.push(buildDraft(_wbActs[_dfi])); } }
        else { data.drafts.push(buildDraft('')); }
    }
    data.draft = data.drafts.length ? data.drafts[0] : null;

    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
})();
