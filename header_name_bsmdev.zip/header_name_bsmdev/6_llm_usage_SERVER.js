/**
 * AI Usage & Cost (Service Portal) — the manager observability page for LLM spend / latency / tokens.
 *
 * Reads x_nose_nfotc_bsm_llm_usage (one row per Chinou call, written by LlmUsage) for a time range and
 * aggregates in JS — cost_usd / *_ms are precision STRINGS (a numeric SUM would round sub-cent costs), and
 * p50/p95 aren't a GlideAggregate operation anyway. Cost + latency are Chinou's OWN reported figures
 * (authoritative, not estimates); tokens populate once the Global ChinouClient emits its metrics object.
 * Manager/admin only (client redirects analysts away). Adds a cost-vs-quality tie-in from the audit table.
 */
(function () {
    // ---- identity + RBAC (mirrors manager-dashboard: admin is NOT auto-expanded into the manager role) ----
    function hasExplicitRole(roleName) {
        try {
            var roles = gs.getUser().getRoles();
            if (!roles) { return false; }
            for (var i = 0; i < roles.length; i++) { if (('' + roles[i]) === roleName) { return true; } }
        } catch (e) { /* fall through */ }
        return false;
    }
    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('Manager');
    var isTestUser = new x_nose_nfotc_bsm.AccessGuard().isDemoUser();
    if (isTestUser && input && input.action === 'set_view') {
        gs.getSession().putClientData('nfotc_view_as', input.viewAs === 'manager' ? 'manager' : 'analyst');
    }
    var viewAs = isTestUser ? ('' + (gs.getSession().getClientData('nfotc_view_as') || '')) : '';
    data.isAdmin = gs.hasRole('admin');
    data.isManager = isTestUser ? (viewAs === 'manager') : hasExplicitRole('x_nose_nfotc_bsm.manager');
    data.isTestUser = isTestUser;
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('Manager');
    if (!data.isManager) { return; }   // client redirects; skip the heavy compute for non-managers

    // ---- time range ----
    var range = (input && input.range) || '7d';
    var daysMap = { 'today': 1, '7d': 7, '30d': 30, 'all': 0 };
    var nDays = (daysMap[range] !== undefined) ? daysMap[range] : 7;
    data.range = range;
    var cutoff = '';
    if (nDays > 0) { var gdt = new GlideDateTime(); gdt.add(-1 * nDays * 24 * 60 * 60 * 1000); cutoff = gdt.getValue(); }

    // wizId -> work-driver name (for the "by driver" breakdown)
    var wizName = {};
    var wz = new GlideRecord('x_nose_nfotc_bsm_wizard');
    wz.query();
    while (wz.next()) { wizName[wz.getUniqueValue()] = wz.getValue('name') || 'Untitled'; }

    function f(v) { var n = parseFloat(v); return isNaN(n) ? 0 : n; }
    function i(v) { var n = parseInt(v, 10); return isNaN(n) ? 0 : n; }
    function pctile(arr, p) {
        if (!arr.length) { return 0; }
        var s = arr.slice().sort(function (a, b) { return a - b; });
        var idx = Math.min(s.length - 1, Math.round(p * (s.length - 1)));
        return s[idx];
    }

    // ---- read usage rows for the range ----
    var totCost = 0, calls = 0, okN = 0, blockedN = 0, errorN = 0;
    var totIn = 0, totOut = 0, totTok = 0, anyTokens = false, anyRt = false;
    var totCf = 0, emailSet = {}, emailCount = 0;
    var byCap = {};          // capability -> {cost, calls, tokens}
    var byDriver = {};       // wizId -> {cost, calls}
    var byEmail = {};        // email_id -> {cost, calls, cf, mail}
    var byDay = {};          // yyyy-MM-dd -> {cost, calls}
    var chinouMs = [], rtMs = [];
    var slowest = [];        // {mail, cap, ms}
    var failures = [];       // {mail, cap, status, error, time}
    var recent = [];         // last N calls for the drill table

    var gr = new GlideRecord('x_nose_nfotc_bsm_llm_usage');
    if (cutoff) { gr.addQuery('sys_created_on', '>=', cutoff); }
    gr.orderByDesc('sys_created_on');
    gr.setLimit(10000);
    gr.query();
    var truncated = gr.getRowCount ? (gr.getRowCount() >= 10000) : false;
    while (gr.next()) {
        var cost = f(gr.getValue('cost_usd'));
        var cms = f(gr.getValue('chinou_ms'));
        var rms = f(gr.getValue('roundtrip_ms'));
        var it = i(gr.getValue('input_tokens')), ot = i(gr.getValue('output_tokens')), tt = i(gr.getValue('total_tokens'));
        var cap = gr.getValue('capability') || 'other';
        var st = gr.getValue('status') || 'error';
        var ok = (gr.getValue('success') === 'true') || st === 'ok';
        var drv = gr.getValue('driver') || '';
        var em = gr.getValue('email_id') || '';
        var mail = gr.getValue('mail_id') || (em ? em.substring(0, 8) : '-');
        var cfc = i(gr.getValue('cashflow_count'));
        var created = gr.getValue('sys_created_on') || '';

        calls++; totCost += cost; totCf += cfc;
        if (ok) { okN++; } else if (st === 'blocked') { blockedN++; } else { errorN++; }
        if (cms > 0) { chinouMs.push(cms); }
        if (rms > 0) { rtMs.push(rms); anyRt = true; }
        if (tt > 0 || it > 0 || ot > 0) { anyTokens = true; }
        totIn += it; totOut += ot; totTok += (tt || (it + ot));
        if (em) { if (!emailSet[em]) { emailSet[em] = true; emailCount++; } }

        if (!byCap[cap]) { byCap[cap] = { cost: 0, calls: 0, tokens: 0 }; }
        byCap[cap].cost += cost; byCap[cap].calls++; byCap[cap].tokens += (tt || (it + ot));
        if (drv) { if (!byDriver[drv]) { byDriver[drv] = { cost: 0, calls: 0 }; } byDriver[drv].cost += cost; byDriver[drv].calls++; }
        if (em) { if (!byEmail[em]) { byEmail[em] = { cost: 0, calls: 0, cf: 0, mail: mail }; } byEmail[em].cost += cost; byEmail[em].calls++; byEmail[em].cf += cfc; }
        var day = created.substring(0, 10);
        if (day) { if (!byDay[day]) { byDay[day] = { cost: 0, calls: 0 }; } byDay[day].cost += cost; byDay[day].calls++; }

        if (cms > 0) { slowest.push({ mail: mail, cap: cap, ms: cms }); }
        if (!ok) { failures.push({ mail: mail, cap: cap, status: st, error: ('' + (gr.getValue('error') || '')).substring(0, 160), time: created }); }
        if (recent.length < 60) {
            recent.push({ cap: cap, mail: mail, email: em, cost: cost, ms: cms, cf: cfc, status: st, ok: ok, time: created });
        }
    }
    data.truncated = truncated;

    // ---- KPIs ----
    data.kpi = {
        cost: totCost, calls: calls, emails: emailCount, cashflows: totCf,
        avgMs: chinouMs.length ? (chinouMs.reduce(function (a, b) { return a + b; }, 0) / chinouMs.length) : 0,
        successRate: calls ? Math.round(okN / calls * 100) : 0,
        tokens: totTok
    };
    // ---- unit economics ----
    data.unit = {
        costPerEmail: emailCount ? (totCost / emailCount) : 0,
        costPerCashflow: totCf ? (totCost / totCf) : 0,
        costPerCall: calls ? (totCost / calls) : 0,
        tokensPerCashflow: (anyTokens && totCf) ? Math.round(totTok / totCf) : 0,
        tokensPerCall: (anyTokens && calls) ? Math.round(totTok / calls) : 0
    };
    // ---- performance ----
    data.perf = {
        avg: chinouMs.length ? Math.round(chinouMs.reduce(function (a, b) { return a + b; }, 0) / chinouMs.length) : 0,
        p50: Math.round(pctile(chinouMs, 0.5)),
        p95: Math.round(pctile(chinouMs, 0.95)),
        rtAvg: rtMs.length ? Math.round(rtMs.reduce(function (a, b) { return a + b; }, 0) / rtMs.length) : 0,
        hasRt: anyRt
    };
    slowest.sort(function (a, b) { return b.ms - a.ms; });
    data.slowest = slowest.slice(0, 5);
    // ---- reliability ----
    data.rel = { ok: okN, blocked: blockedN, error: errorN, total: calls };
    failures.sort(function (a, b) { return (a.time < b.time) ? 1 : -1; });
    data.failures = failures.slice(0, 8);
    // ---- tokens ----
    data.tokens = { has: anyTokens, input: totIn, output: totOut, total: totTok };

    // ---- by capability (ranked) ----
    var caps = [];
    for (var ck in byCap) { caps.push({ key: ck, cost: byCap[ck].cost, calls: byCap[ck].calls, tokens: byCap[ck].tokens }); }
    caps.sort(function (a, b) { return b.cost - a.cost; });
    data.byCapability = caps;
    // ---- by driver (ranked, named) ----
    var drivers = [];
    for (var dk in byDriver) { drivers.push({ key: dk, name: wizName[dk] || (dk.substring(0, 8) + '…'), cost: byDriver[dk].cost, calls: byDriver[dk].calls }); }
    drivers.sort(function (a, b) { return b.cost - a.cost; });
    data.byDriver = drivers;
    // ---- spend over time (days with data, ascending) ----
    var days = [];
    for (var dd in byDay) { days.push({ day: dd, cost: byDay[dd].cost, calls: byDay[dd].calls }); }
    days.sort(function (a, b) { return (a.day < b.day) ? -1 : 1; });
    data.byDay = days;
    // ---- top emails by cost ----
    var emails = [];
    for (var ek in byEmail) { emails.push({ id: ek, mail: byEmail[ek].mail, cost: byEmail[ek].cost, calls: byEmail[ek].calls, cf: byEmail[ek].cf }); }
    emails.sort(function (a, b) { return b.cost - a.cost; });
    data.topEmails = emails.slice(0, 8);
    // ---- recent calls (already newest-first, capped at 60) ----
    data.recent = recent.slice(0, 40);

    // ---- cost-vs-quality tie-in (from the audit trail) ----
    var conf = { High: 0, Medium: 0, Low: 0, none: 0 };
    var extracted = 0, overridden = 0;
    var ag = new GlideRecord('x_nose_nfotc_bsm_audit');
    if (cutoff) { ag.addQuery('sys_created_on', '>=', cutoff); }
    ag.addQuery('event_type', 'IN', 'cashflow.extracted,extraction.overridden');
    ag.setLimit(10000);
    ag.query();
    while (ag.next()) {
        var et = ag.getValue('event_type');
        if (et === 'cashflow.extracted') {
            extracted++;
            var cl = ag.getValue('confidence_level');
            if (cl === 'High') { conf.High++; } else if (cl === 'Medium') { conf.Medium++; } else if (cl === 'Low') { conf.Low++; } else { conf.none++; }
        } else if (et === 'extraction.overridden') { overridden++; }
    }
    data.quality = {
        conf: conf, extracted: extracted, overridden: overridden,
        overrideRate: extracted ? Math.round(overridden / extracted * 100) : 0,
        has: (extracted > 0)
    };
})();
