/**
 * Audit Trail view (Service Portal) — the reconstruct-and-review surface over x_nose_nfotc_bsm_audit.
 * Read-only. Shows every captured system action + AI inference newest-first, with KPI cards (extractions,
 * override rate, AI acceptance, write-backs). Scoped to a cashflow (?cf) or email (?eml) to reconstruct
 * that item's full processing trail (BRD §10 reproducibility); otherwise shows the whole trail.
 */
(function () {
    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
    data.homeUrl = '/nfotcbsm?id=bsm_work_drivers';
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('User');
    // Show the manager console sidebar only for EXPLICIT managers (analysts — incl. admins without the
    // manager role — reach this via a per-cashflow link and should NOT get the manager nav).
    function hasExplicitRole(roleName) {
        try {
            var roles = gs.getUser().getRoles();
            if (!roles) { return false; }
            for (var i = 0; i < roles.length; i++) { if (('' + roles[i]) === roleName) { return true; } }
        } catch (e) { /* fall through */ }
        return false;
    }
    // Mirror the Manager Dashboard's role resolution so the sidebar is consistent across manager pages —
    // incl. the test-user view-as toggle (an admin viewing AS a manager). Real analysts / admins-without-
    // the-role reaching this via a case drilldown still get no manager nav.
    var isTestUser = new x_nose_nfotc_bsm.AccessGuard().isDemoUser();   // demo operators (x_nose_nfotc_bsm.demo_users) get the view-as toggle
    var viewAs = isTestUser ? ('' + (gs.getSession().getClientData('nfotc_view_as') || '')) : '';
    data.isAdmin = gs.hasRole('admin');
    data.isManager = isTestUser ? (viewAs === 'manager') : hasExplicitRole('x_nose_nfotc_bsm.manager');
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('User');

    var cfParam = $sp.getParameter('cf') || '';
    var emlParam = $sp.getParameter('eml') || '';
    data.scoped = !!(cfParam || emlParam);
    // When the analyst opened the audit FROM a specific cashflow (?cf=), the top-left nav returns to THAT
    // cashflow's case screen ("← Back") instead of the work-drivers home; otherwise keep the usual "← Home".
    data.backUrl = cfParam ? ('/nfotcbsm?id=bsm_ai_extraction&cf=' + cfParam) : data.homeUrl;
    data.backLabel = cfParam ? 'Back' : 'Home';
    data.scopeLabel = '';

    // ── ACCESS GUARD ── the audit trail carries counterparty, amounts, AI values and overrides. This widget's
    // server GlideRecord bypasses table ACLs, so gate here: scoped to a cashflow/email -> the caller must be
    // able to view that item's owning work-driver; the UNSCOPED whole-estate trail is manager/admin only
    // (an analyst must not read every wizard's audit by hitting the page with no ?cf/?eml).
    var _agv = new x_nose_nfotc_bsm.AccessGuard();
    var _auditOk;
    if (cfParam) { var _acg = new GlideRecord('x_nose_nfotc_bsm_cashflow'); _auditOk = _acg.get(cfParam) && _agv.canViewCashflow(_acg); }
    // Owning wizard = wiz_extracted OR wiz_assigned (a claimed-but-not-extracted mail has only wiz_assigned),
    // so an assigned analyst isn't wrongly bounced from their own mail's audit trail.
    else if (emlParam) { var _aeg = new GlideRecord('x_nose_nfotc_bsm_email'); _auditOk = _aeg.get(emlParam) && _agv.canViewWizard('' + (_aeg.getValue('wiz_extracted') || _aeg.getValue('wiz_assigned'))); }
    else { _auditOk = _agv.isManagerOrAdmin(); }
    if (!_auditOk) {
        data.redirect = '/nfotcbsm?id=bsm_work_drivers';
        data.rows = []; data.eventTypes = []; data.kpis = []; data.empty = true;
        return;
    }

    var LABEL = {
        'classification.decided': 'Relevance Decision',
        'cashflow.extracted': 'AI Extraction',
        'extraction.confirmed': 'Extraction Confirmed',
        'extraction.overridden': 'Field Override',
        'match.selected': 'Match Selected',
        'match.no_match': 'No Match',
        'match.confirmed': 'Match Confirmed',
        'writeback': 'Write-back',
        'writeback.mo': 'Sent to Middle Office',
        'wizard.publish': 'Wizard Published',
        'wizard.save_draft': 'Wizard Saved'
    };

    // Resolve a cashflow's position within its email ("cf3 of 31") so per-cashflow rows are
    // distinguishable — one multi-cashflow email otherwise produces many identical-looking rows.
    var _cfLabel = {}, _emailCfs = {};
    function cashflowLabel(cfId) {
        if (!cfId) { return ''; }
        if (Object.prototype.hasOwnProperty.call(_cfLabel, cfId)) { return _cfLabel[cfId]; }
        var lbl = '';
        var c = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (c.get(cfId)) {
            var em = c.getValue('email');
            if (!_emailCfs[em]) {
                var ids = [];
                var q = new GlideRecord('x_nose_nfotc_bsm_cashflow');
                q.addQuery('email', em);
                q.orderBy('flow_index');
                q.query();
                while (q.next()) { ids.push(q.getUniqueValue()); }
                _emailCfs[em] = ids;
            }
            var ids2 = _emailCfs[em], pos = ids2.indexOf(cfId);
            if (pos > -1) { lbl = 'cf' + (pos + 1) + (ids2.length > 1 ? ' of ' + ids2.length : ''); }
        }
        _cfLabel[cfId] = lbl;
        return lbl;
    }
    var _dir = new x_nose_nfotc_bsm.TaggingDashboard();

    var gr = new GlideRecord('x_nose_nfotc_bsm_audit');
    if (cfParam) { gr.addQuery('cashflow_id', cfParam); }
    else if (emlParam) { gr.addQuery('email_id', emlParam); }
    gr.orderByDesc('sys_created_on');
    gr.setLimit(300);
    gr.query();

    var rows = [], ev = {}, evOpts = {};
    while (gr.next()) {
        var et = gr.getValue('event_type');
        if (('' + et).indexOf('wizard') === 0) { continue; }   // wizard lifecycle is NOT part of the audit trail
        ev[et] = (ev[et] || 0) + 1;
        evOpts[et] = LABEL[et] || et;

        // AI value + confidence: prefer the explicit columns; for AI-inference events with no explicit
        // ai_value, synthesise a compact "CCY amount · direction · VD date" from the ai_attributes blob.
        var aiValue = gr.getValue('ai_value'), confidence = '', confLevel = '';
        var axRaw = gr.getValue('ai_attributes');
        if (axRaw) {
            try {
                var ax = JSON.parse(axRaw) || {};
                if (ax.confidence != null && ('' + ax.confidence) !== '') { confidence = '' + ax.confidence; }
                // Confidence is shown as a plain level (High/Medium/Low). Prefer an explicit level in the
                // payload; otherwise bucket the stored numeric (kept in the JSON for the audit record).
                if (ax.confidence_level) { confLevel = '' + ax.confidence_level; }
                else if (confidence !== '' && !isNaN(parseFloat(confidence))) {
                    var _cn = parseFloat(confidence);
                    confLevel = _cn >= 85 ? 'High' : (_cn >= 65 ? 'Medium' : 'Low');
                }
                if (!aiValue) {
                    var parts = [];
                    var head = (('' + (ax.currency || '')) + ' ' + ('' + (ax.amount || ''))).trim();
                    if (head) { parts.push(head); }
                    if (ax.direction) { parts.push(_dir._normDir(ax.direction)); }
                    if (ax.value_date) { parts.push('VD ' + ax.value_date); }
                    if (parts.length) { aiValue = parts.join(' · '); }
                }
            } catch (eax) { /* leave aiValue as-is */ }
        }

        rows.push({
            ts: gr.getDisplayValue('sys_created_on'),
            mailId: gr.getValue('mail_id'),
            cashflowLabel: cashflowLabel(gr.getValue('cashflow_id')),
            counterparty: gr.getValue('counterparty'),
            event: LABEL[et] || et,
            eventKey: et,
            actor: gr.getValue('actor'),
            field: gr.getValue('field_name'),
            aiValue: aiValue,
            confidence: confidence,
            confLevel: confLevel,
            analystValue: gr.getValue('analyst_value'),
            summary: gr.getValue('summary'),
            ai: axRaw,
            cashflowId: gr.getValue('cashflow_id')
        });
        if (data.scoped && !data.scopeLabel && gr.getValue('mail_id')) { data.scopeLabel = gr.getValue('mail_id'); }
    }
    data.rows = rows;
    data.eventTypes = [];
    for (var k in evOpts) { data.eventTypes.push({ key: k, label: evOpts[k] }); }

    var extracted = ev['cashflow.extracted'] || 0, confirmed = ev['extraction.confirmed'] || 0, overridden = ev['extraction.overridden'] || 0;
    var denom = confirmed + overridden;
    data.kpis = [
        { label: 'Total Events', num: '' + rows.length, cls: '' },
        { label: 'AI Extractions', num: '' + extracted, cls: 'n-blue' },
        { label: 'Field Overrides', num: '' + overridden, cls: 'n-amber' },
        { label: 'Override Rate', num: (denom ? Math.round(overridden / denom * 100) : 0) + '%', cls: 'n-amber' },
        { label: 'AI Acceptance', num: (denom ? Math.round(confirmed / denom * 100) : 100) + '%', cls: 'n-green' },
        { label: 'Write-backs', num: '' + ((ev['writeback'] || 0) + (ev['writeback.mo'] || 0)), cls: 'n-green' }
    ];
    data.empty = !rows.length;
})();
