﻿/**
 * OTC Analyst Screen — Service Portal widget SERVER script.
 * Faithful replica of the classic UI Page (AnalystScreen.server.js): shows one email's
 * mail contents + extracted fields, with a Confirm action and an email picker.
 * Runs server-side (GlideRecord) and reuses the EmlFieldExtractor Script Include for the
 * mail contents. Talks to the client via data / input (c.server.update).
 */
(function () {
    // ── ACCESS GUARD ── OTC analyst case screen. This widget's server GlideRecord bypasses table ACLs, so
    // authorization is enforced here. Non-analysts bounce to the landing page; each write action below is
    // ADDITIONALLY gated (_canActCf / _canActEmail) so a viewer can't confirm/resolve/override a cashflow
    // for a work-driver that isn't assigned to them (only the assigned analyst may act — FR-UI-022).
    var _ag = new x_nose_nfotc_bsm.AccessGuard();
    if (!_ag.canViewAny()) { data.redirect = '/nfotcbsm?id=bsm_work_drivers'; return; }
    function _canActCf(cfSysId) { if (!cfSysId) { return false; } var _g = new GlideRecord('x_nose_nfotc_bsm_cashflow'); return _g.get('' + cfSysId) ? _ag.canActOnCashflow(_g) : false; }
    function _canActEmail(emId) { if (!emId) { return false; } var _e = new GlideRecord('x_nose_nfotc_bsm_email'); return _e.get('' + emId) ? _ag.isAssignedAnalyst('' + (_e.getValue('wiz_extracted') || _e.getValue('wiz_assigned'))) : false; }

    var ex = new x_nose_nfotc_bsm.EmlFieldExtractor();
    function setIf(gr, col, v) { if (v !== null && v !== undefined) { gr.setValue(col, '' + v); } }
    // Value date: store ISO (YYYY-MM-DD, needed for matching), show/edit as DD-MM-YYYY.
    function vdDisp(v) { var m = ('' + (v || '')).match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? (m[3] + '-' + m[2] + '-' + m[1]) : ('' + (v || '')); }
    function vdIso(v) { v = '' + (v || ''); if (/^\d{4}-\d{2}-\d{2}$/.test(v)) { return v; } var m = v.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/); return m ? (m[3] + '-' + ('0' + m[1]).slice(-2) + '-' + ('0' + m[2]).slice(-2)) : v; }
    // RFC2822 Date header ("Mon, 16 Jun 2026 09:23:45 +0000") -> "16-06-2026 09:23:45".
    function fmtReceived(raw) {
        raw = '' + (raw || '');
        var m = raw.match(/(\d{1,2})\s+([A-Za-z]{3})[A-Za-z]*\s+(\d{4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
        if (!m) { return raw; }
        var mo = { jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06', jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12' }[m[2].toLowerCase()] || '01';
        return ('0' + m[1]).slice(-2) + '-' + mo + '-' + m[3] + ' ' + ('0' + m[4]).slice(-2) + ':' + m[5] + ':' + (m[6] || '00');
    }

    // Step 3 draft — pull the counterparty settlement address out of the From header.
    function extractEmail(s) {
        s = '' + (s || '');
        var m = s.match(/<([^>]+)>/); if (m) { return m[1].trim(); }
        m = s.match(/[\w.+-]+@[\w.-]+\.\w+/); return m ? m[0] : '';
    }
    // Amount -> thousands-separated with 2 decimals.
    function fmtAmt(v) {
        var n = parseFloat(('' + (v || '')).replace(/,/g, ''));
        if (isNaN(n)) { return '' + (v || '-'); }
        var p = n.toFixed(2).split('.');
        p[0] = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return p.join('.');
    }
    // Flip our-POV direction back to the counterparty's POV for outbound replies.
    function flipDir(d) {
        var s = ('' + (d || '')).trim().toLowerCase();
        if (s === 'pay') { return 'Receive'; }
        if (s === 'receive') { return 'Pay'; }
        return d || '-';
    }
    // A labelled key/value line, values aligned in the monospace draft.
    function drow(label, val) { return '  ' + (label + '                    ').slice(0, 18) + ('' + (val === '' || val == null ? '-' : val)); }
    function detailBlock(ref, ccy, amt, dir, vd) {
        return drow('Trade reference', ref) + '\n' + drow('Currency', ccy) + '\n' +
            drow('Amount', fmtAmt(amt)) + '\n' + drow('Direction', dir) + '\n' + drow('Value date', vd);
    }

    // Step 3 draft, DERIVED from the effective outcome (matched / mismatch / no_match).
    function buildDraft(outcome) {
        var ref = data.reference || '(no reference)';
        var ccy = data.currency || '', amt = data.amount || '', vd = data.value_date || '';
        var cp = data.counterparty || 'Counterparty';
        var cpEmail = extractEmail(data.mail.from) || '(counterparty settlement address)';
        var subj = ref + ' (' + ccy + ', value ' + vd + ')';
        var greet = 'Dear ' + cp + ' Settlements,\n\n';
        var quoted = '\n\n-----  Original message  -----\nFrom: ' + (data.mail.from || '') + '\nSubject: ' + (data.mail.subject || '') + '\n\n' + (data.mail.body || '');

        if (outcome === 'matched') {
            var blkM = detailBlock(ref, ccy, amt, flipDir(data.direction), vd);
            return { title: 'Reply to counterparty — agree the details',
                to: cpEmail, subject: 'RE: Trade confirmation — ' + subj,
                body: greet + 'Thank you for your settlement confirmation. We confirm that we agree the details below, including the settlement instructions.\n\n' + blkM + '\n\nNo further action is required from your side. The payment will settle on the value date shown.\n\nKind regards,\nSettlements' + quoted,
                sendLabel: 'Send to counterparty' };
        }
        if (outcome === 'no_match') {
            var blkN = detailBlock(ref, ccy, amt, flipDir(data.direction), vd);
            return { title: 'Reply to counterparty — no matching booking found',
                to: cpEmail, subject: 'RE: Trade confirmation — ' + subj,
                body: greet + 'Thank you for your settlement confirmation. We are unable to locate a matching booking in our systems for the cash flow below:\n\n' + blkN + '\n\nSo that we can investigate further, please could you share:\n  •  your internal trade reference and any UTI / USI\n  •  the executing desk or trader on your side\n  •  the execution venue and timestamp\n  •  confirmation of the legal entity you booked against\n\nWe will hold the payment pending your response.\n\nKind regards,\nSettlements' + quoted,
                sendLabel: 'Send to counterparty' };
        }
        // mismatch -> refer to Middle Office (internal; both sides shown from our POV so direction agrees).
        var bk = (data.cmp && data.cmp.booking) ? data.cmp.booking : null;
        var diffs = (data.cmp && data.cmp.banner) ? data.cmp.banner.diffs.concat(data.cmp.banner.miss).join(', ') : '';
        var cpBlk = detailBlock(ref, ccy, amt, data.direction, vd);
        var bkBlk = bk ? detailBlock(bk.bank_trade_ref || bk.reference || '-', bk.currency || ccy, bk.amount, bk.direction || data.direction, bk.value_date || vd) : '  (booking details unavailable)';
        return { title: 'Refer to Middle Office',
            to: 'middleoffice@abc.com', subject: 'Referral: Trade confirmation — ' + subj,
            body: 'Referring the following for review. The counterparty’s details and our booking agree in part but differ on the field(s)' + (diffs ? ': ' + diffs : ' noted below') + '.\n\nCounterparty: ' + cp + '\nSource email: ' + data.ref + '\n\nCounterparty submitted:\n' + cpBlk + '\n\nBooked by the bank:\n' + bkBlk + '\n\nPlease advise on the correct economics so we can respond to the counterparty.\n\nRegards,\nSettlements' + quoted,
            sendLabel: 'Send to Middle Office' };
    }

    // Build one trade row for the table.
    function mkTrade(sysId, ref, vd, amt, ccy, dir, prod) {
        return {
            sys_id: sysId, reference: ref || '', value_date: vdDisp(vd), amount: amt || '',
            currency: ccy || '', direction: dir || '', product_type: prod || ''
        };
    }

    // Save action (c.save() -> input.action = 'save'): persist the shared counterparty + every edited
    // trade row back onto its cashflow child, and keep the parent summary in sync with the first trade.
    if (input && input.action === 'save' && input.id && _canActEmail(input.id)) {
        // Gate the cashflow write on the CASHFLOW's own assignment (_canActCf), not just the email's — a
        // client can post their own email id (passes _canActEmail) with a FOREIGN cfSysId, so authorising only
        // the email would let them overwrite another wizard's cashflow economics (the match inputs).
        if (input.cfSysId && _canActCf(input.cfSysId)) {
            var cfg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
            if (cfg.get(input.cfSysId)) {
                setIf(cfg, 'reference', input.reference);
                setIf(cfg, 'currency', input.currency);
                setIf(cfg, 'amount', input.amount);
                setIf(cfg, 'direction', input.direction);
                setIf(cfg, 'value_date', vdIso(input.value_date));
                cfg.update();
            }
        }
        var sg = new GlideRecord('x_nose_nfotc_bsm_email');
        if (sg.get(input.id)) { setIf(sg, 'counterparty_name', input.counterparty); sg.update(); }
        data.saved = true;
    }

    // Confirm action (c.confirm() -> input.action = 'confirm'): confirm THIS cashflow only, so each
    // cashflow in a multi-trade mail is confirmed independently. Mails with no extracted cashflow
    // fall back to confirming the email record itself.
    if (input && input.action === 'confirm') {
        if (input.cfSysId && _canActCf(input.cfSysId)) {
            var ccg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
            if (ccg.get(input.cfSysId)) { ccg.setValue('confirmed', 'true'); ccg.update(); }
        } else if (input.id && _canActEmail(input.id)) {
            var cg = new GlideRecord('x_nose_nfotc_bsm_email');
            if (cg.get(input.id)) { cg.setValue('review_status', 'awaiting_review'); cg.update(); }
        }
    }

    // Analyst outcome writeback (HITL): confirm/override the match outcome for THIS cashflow.
    if (input && input.action === 'outcome' && input.cfSysId && input.outcomeChoice && _canActCf(input.cfSysId)) {
        var og = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        // Changing the outcome un-confirms the review (step 2 back to amber, step 3 hidden until re-confirmed).
        if (og.get(input.cfSysId)) { og.setValue('analyst_outcome', input.outcomeChoice); og.setValue('review_confirmed', ''); og.setValue('resolution', ''); og.update(); }
    }
    if (input && input.action === 'reset_outcome' && input.cfSysId && _canActCf(input.cfSysId)) {
        var rg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (rg.get(input.cfSysId)) { rg.setValue('analyst_outcome', ''); rg.setValue('review_confirmed', ''); rg.setValue('resolution', ''); rg.update(); }
    }
    // Confirm the Step 2 review -> locks the (auto/overridden) outcome and turns step 2 green.
    if (input && input.action === 'confirm_review' && input.cfSysId && _canActCf(input.cfSysId)) {
        var cvg = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (cvg.get(input.cfSysId)) {
            if (input.outcomeChoice) { cvg.setValue('analyst_outcome', input.outcomeChoice); }
            cvg.setValue('review_confirmed', 'true');
            cvg.update();
        }
    }
    // Step 3 next-action writeback (demo — records the decision; no real email is sent).
    if (input && input.action === 'send' && input.cfSysId && _canActCf(input.cfSysId)) {
        var sd = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (sd.get(input.cfSysId)) { sd.setValue('resolution', 'sent'); sd.update(); }
    }
    if (input && input.action === 'resolve' && input.cfSysId && _canActCf(input.cfSysId)) {
        var rd = new GlideRecord('x_nose_nfotc_bsm_cashflow');
        if (rd.get(input.cfSysId)) { rd.setValue('resolution', 'closed'); rd.update(); }
    }

    // Which record to show: a dashboard cashflow (?cf) resolves to its parent email; ?eml opens an
    // email directly; else client pick (input.id); else the latest extracted/partial; else latest any.
    var cfParam = $sp.getParameter('cf') || (input && input.cfParam) || '';
    var emlParam = $sp.getParameter('eml') || (input && input.emlParam) || '';
    var emailFromCf = '';
    if (cfParam) { var cfr = new GlideRecord('x_nose_nfotc_bsm_cashflow'); if (cfr.get(cfParam)) { emailFromCf = cfr.getValue('email'); } }
    var wantId = (input && input.id) || emailFromCf || emlParam || '';
    var gr = new GlideRecord('x_nose_nfotc_bsm_email');
    var found = wantId ? gr.get(wantId) : false;
    if (!found) {
        var q = new GlideRecord('x_nose_nfotc_bsm_email');
        q.addQuery('extraction_status', 'IN', 'extracted,partial');
        q.orderByDesc('sys_created_on'); q.setLimit(1); q.query();
        if (q.next()) {
            gr = q;
        } else {
            var a = new GlideRecord('x_nose_nfotc_bsm_email');
            a.orderByDesc('sys_created_on'); a.setLimit(1); a.query();
            if (!a.next()) { data.empty = true; return; }
            gr = a;
        }
    }

    // PER-RECORD VIEW GUARD: the caller must be able to view THIS mail's owning work-driver
    // (wiz_extracted||wiz_assigned) — canViewAny() at the top only proves they're SOME analyst. Closes a
    // hand-typed ?cf=/?eml=/picker id (and the latest-mail fallback) exposing another wizard's case. Managers pass.
    if (!_ag.canViewWizard('' + (gr.getValue('wiz_extracted') || gr.getValue('wiz_assigned')))) {
        data.redirect = '/nfotcbsm?id=bsm_work_drivers'; data.empty = true; return;
    }

    data.empty = false;
    data.id = gr.getUniqueValue();
    // Header title = the email id (file name) without the .eml extension, e.g. "EML-0007".
    data.ref = ('' + (gr.getValue('name') || '')).replace(/\.eml$/i, '') || '(no id)';
    data.counterparty = gr.getValue('counterparty_name');
    // This case screen shows ONE trade's detail: the clicked cashflow (?cf). Fall back to the email's
    // first cashflow, or the email summary when a mail has no extracted cashflow.
    var cfRec = null;
    if (cfParam) { var cfg2 = new GlideRecord('x_nose_nfotc_bsm_cashflow'); if (cfg2.get(cfParam) && cfg2.getValue('email') === gr.getUniqueValue()) { cfRec = cfg2; } }
    if (!cfRec) { var f1 = new GlideRecord('x_nose_nfotc_bsm_cashflow'); f1.addQuery('email', gr.getUniqueValue()); f1.orderBy('flow_index'); f1.setLimit(1); f1.query(); if (f1.next()) { cfRec = f1; } }
    data.cfSysId = cfRec ? cfRec.getUniqueValue() : '';
    data.analystOutcome = cfRec ? (cfRec.getValue('analyst_outcome') || '') : '';
    data.reviewConfirmed = cfRec ? (cfRec.getValue('review_confirmed') === 'true') : false;
    data.reference = cfRec ? cfRec.getValue('reference') : '';
    data.currency = cfRec ? cfRec.getValue('currency') : '';
    data.amount = cfRec ? cfRec.getValue('amount') : '';
    data.direction = cfRec ? cfRec.getValue('direction') : '';
    data.value_date = vdDisp(cfRec ? cfRec.getValue('value_date') : '');
    data.confirmed = cfRec ? (cfRec.getValue('confirmed') === 'true') : (gr.getValue('review_status') === 'awaiting_review');
    data.cfParam = cfParam;   // round-tripped so ?cf survives c.server.update() (confirm/save reloads)
    data.emlParam = emlParam;

    // Cashflow navigator (multi-trade mails): ordered list of the email's cashflows + current index.
    data.cfList = [];
    var lcf = new GlideRecord('x_nose_nfotc_bsm_cashflow');
    lcf.addQuery('email', gr.getUniqueValue());
    lcf.orderBy('flow_index');
    lcf.query();
    while (lcf.next()) { data.cfList.push(lcf.getUniqueValue()); }
    data.cfTotal = data.cfList.length;
    data.cfIndex = 0;
    for (var ni = 0; ni < data.cfList.length; ni++) { if (data.cfList[ni] === data.cfSysId) { data.cfIndex = ni + 1; break; } }

    // Mail contents from the raw .eml (NOT the extracted .xlsx). An attachment mail carries two
    // sys_attachments — the .eml and the materialised Cashflows.xlsx — so pick the .eml explicitly
    // (else mailContents would parse the spreadsheet bytes as the email -> garbage). Other files
    // become the "Attachment:" line; the .eml sys_id backs the header Download button.
    data.mail = { to: '', from: '', cc: '', subject: '', body: '', attachment: '', received: '' };
    data.emlAttId = '';
    var attNames = [];
    var ag = new GlideRecord('sys_attachment');
    ag.addQuery('table_name', 'x_nose_nfotc_bsm_email');
    ag.addQuery('table_sys_id', gr.getUniqueValue());
    ag.orderBy('sys_created_on');
    ag.query();
    while (ag.next()) {
        var ctype = ag.getValue('content_type') || '';
        var fname = ag.getValue('file_name') || '';
        if (!data.emlAttId && (ctype === 'message/rfc822' || /\.eml$/i.test(fname))) {
            data.emlAttId = ag.getUniqueValue();
        } else {
            attNames.push(fname);
        }
    }
    if (data.emlAttId) {
        var m = ex.mailContents(data.emlAttId) || {};
        data.mail.to = m.to || ''; data.mail.from = m.from || ''; data.mail.cc = m.cc || '';
        data.mail.subject = m.subject || ''; data.mail.body = m.body || '';
        data.mail.received = fmtReceived(m.date);
    }
    data.mail.attachment = attNames.join(', ');

    // Email picker options (all uploaded emails).
    data.emails = [];
    var g = new GlideRecord('x_nose_nfotc_bsm_email');
    g.orderBy('name'); g.setLimit(500); g.query();
    while (g.next()) {
        var eid = g.getUniqueValue();
        var lbl = g.getValue('name') || eid;
        var st = g.getValue('extraction_status');
        if (st) { lbl += '  ·  ' + st; }
        data.emails.push({ id: eid, label: lbl });
    }

    // Step 2 (Compare & Match): only after the analyst confirms the extracted fields. Compares the
    // clicked cashflow (?cf); without one, the email's first cashflow (or the email as a whole).
    data.dashUrl = '/nfotcbsm?id=bsm_analystdashboard';
    data.cmp = null;
    if (data.confirmed) {
        var cm = new x_nose_nfotc_bsm.CompareMatch();
        data.cmp = data.cfSysId ? cm.buildData(data.cfSysId, '') : cm.buildData('', gr.getUniqueValue());
    }
    // Effective outcome = the analyst's override if set, else the system's computed outcome.
    data.effectiveOutcome = data.analystOutcome || (data.cmp ? data.cmp.systemOutcome : '');
    // Step 3: the derived next-action draft + its resolution state.
    data.resolution = cfRec ? (cfRec.getValue('resolution') || '') : '';
    data.draft = (data.confirmed && data.cmp && data.effectiveOutcome) ? buildDraft(data.effectiveOutcome) : null;

    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    // Header identity (name + avatar initials) from the ONE helper - was a hardcoded 'US' in the template.
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('User');
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('User');

    // Nomura logo (same mark used across the app).
    data.logo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAP0AAACUCAMAAABvEN9cAAAAmVBMVEX////XETTWACXXDjL88PH76+3keYPhZXPVACDWACzWCC/UACLxvMPkbn799vbTAADusbjUABPsnqfuqbHnhpLbO1TjbnbVABvcRk7UAA3jc3v44eTzyM310db32t7so6rhXW3ol53XKznbO0rokZzfVWfmfYveVGDZLEnlipHbRlfbT1PaLkPWGCvZHzvdTlnfXmTZP0TkgoZLqeShAAAKu0lEQVR4nO1aa3uiuhaGBIQgclHbFEHUamvbbZ3Z8/9/3IGErFygnZnaZ58v6/3Qp2BI1pusO3geAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoH4r5Bl4TYtirQJg+z/LctNyEKFMQ95P3DuBu0q8vM8r6rujx+tWneA83wYuku544IPZbBvh1P4dP8/Y9ej2UcS+5M7IJvJ+7ak6YxVJPEHUFIls3TERw49D1Nv5fVpWGpWO+MOSoafqSOB/GE/3FbDLDwv0+2HG1DAI83k72k+JxL5wWX/wrvbVWTea2YkBurDBsRkMzn3MpcT85kkGcfick529rjwvlIiLB0JSvFIuZKXPCZjxDy+e53m5nlXPoyqfk3uUMoVi4S7O3/HutvzhXFrdeRUkU60AvCLQ0jgjQ0TPwjdKPJhONnYthLek+GX0mVPxGpkYJ84+67A+NFWUIVtDkPe2mn2FEY8bj9nnx0SprYq55TySl2yZGQ33vZdbY4vpL+DZ1/so/qMfWKyZx+w79YnkTeBxRxGqDk+ZO+TfywKLvtsGQ8EaOWnnbsJi5dKMSKu3XgzBvNuunnrCtaJ7bFfYM/mHYixGTTejLmFj5pbHE05J5O9TyKTvst+VQ1DEy3+qRpEoNzZ3PAfYJ8cu8N+JnqZs+X3/p49e4uixeLp8q73gzLn2V44vaTv8+3od4c9Ja8fs2+JsmNqOIjifRCAXe3pV76hVAcvOxonZXuYv2ZP2fB8uDxqBfvhhBIvOzPfWHM24fcs9h0x4wQd9nsOu2zOs1Sic0txvJmx8eRnDT5QSmL6vS+wL9SI9oealiau5y2uJjVK3N0ZsffJUXskm30KLtu2oHARDz9UpjPbmmz7w1rG+jpJTEluYe+1pZo0doJaZu5/L95EXHLY+7G2SZu9ctnJtXBmuA5CkTvj7s7UOp+/ZllpXFemk7iJvRepXSV7+3C3UmId0q6/Z+/HT5PsYY/ZT8d+tPC5Xj7czM1J2UvrPTHz+tvYN0on3ZC+E7PSBPjl45xoxJ7y5yn24LKTUWKxVAvAk51MTmZSFlpMIYkh6W3sg3xYnd1ZbrfeE3FWa+BHnjwXA3tq7EG+mmD/r1r5cRQ5GuXOE9CtbFlKMSmsnHnXRG9JbGQnt7EHi2JvlmTNnIogVv8A8y9Hfk+wp/6T4aTovBmx36rEIXkYbWD2Uz1bqelrMV1yXGi1a71Dvt+Dh86/jb3KotjZ1PzguQ9R9Lj1XsEG57Np9uzUXLWqkofaZQ/Rm02klAvFKVZSNeJA2H19hnj47NU03RG1HZUmehv7WhnU3CofWjG4l7a5KGbJo1uMD+zX2np9FdRM9mv163yinoAf2ZAsZWLj/S79elVFFOVZcArBSDo9/Sb2K4jEVv68EypBClM1KXWTfWAfGOGxuw5s9rPR8RpYqX1TihFKOd9DHQ79vPBCL4vAwN7BA9/GHirJi+nSM5EEJhexEbo8iJx4Bey98E7TT5KVzR6k5hOldApm8WSeB9l3k0ZqUpkNHLQkECBuYr9UTo9YRi0DTCUUNbio00kuThGv2Xt1qU2fJc00+3KiWGjAJQ7q/CJGi/h60m6+dyb1v6D6kJffwL6eDUZHyYuVgT4JV5dLO9dabdUxNnudzPbCseCP2W8d9tIRUS5+A0snYo29ji0q8/wq+7qIqPKipW85tFBIMD97hjyC1dnOiEz23kHX4D6hJvuff8R+cGXS55VyTti35NgbXQrxB1T1S+yjMs8ryZ0mjCzsB6UEuZIVGiu+U4db7LOFUYrwxdPfar5kn8mkZsh7wSVKj5tBx4GpgupL7Jt3babHe1eodymN8nFaqeN7y0As9l74ZNalYn6X/YTXK8CWhdcrxBaSs1w7eATVj/SxCEkON7DX1c3IlXU7LqTlS+hnQ5pBmSW/zb4rTO2ycBTx3BZODwgpxNipXHmmmRJTpqLaCFVR9jX20CmjyaipJp0L2882A8Dr++WrGfQc9l7xaJWmOttRl2t3KSPbEY6tFX4uuULWq32OIHfRyUd6A3vvGRL8o6P4KrsT3b8OsdEBZFdT9V32djMM2Bf0TzJd3kslY5zRvgG6MoWE5Kyv+m9gH/qKU/xqJzFr5wAtWK2FEXtvH1ujf1/lBBAQeHfemeSiWnftdkg6e6mv/c0whuRD6kcAvYC/i3g7tY2U2LXt+TP2VmthzN67Wg//bYWbCrWDtu1yn2WqF+zzQ9Z3nGB7pW/IPmQfSuUmxST7GgJZbGWwsq1EEwGWDABCuUFggn3NTfqqu6EkTJx0qcsS4Oj7WWRdo/x5tslDb6HcPDv2yUYDPS4iY9KvuTmBKYk83aHiHuV6hd5Gw5OHG3n7wYJuKTOjyTHB3kuJQX/c2XLKRKOz1XFrRU0Lr2uaY/XqNZBEVal1ZkOL56TYW51BD+I0aafZh5F6kF304ctanTgN7Eb3vnPt96bYewcwTd3VVKFw3NVU3kcklqlo55D7YYt2cZJ09ZNaeR71teMBDl/2wnbKpcrkWGPIDZJsmr1X6AoSfFl2EG0NV0rD3rgu0ifZB3oosIe2HNnbHW04gD4RyqTis4P+sdPKnaJLxTE20GhNYnkuigS3ZZbWCqo6Yh+A2unGhdQsdnYbGXqnZMr9MXuv3ut2kEqhI3ibcTCUKjtAuOrf1rXC50EEbjq9mO+9Laxc9l6jhrLXz3tTyKD0sYU+yU2DvGlc46WQSMbqQFPZVho1YUIdCRJQlGn2hpnoN1nKbybvRshcwZusS8+4kC2VSG1Nt2P0PdT9bUb7+0tdcorK4ASCMaM9tZJJlG4BTtT3Rg0lg0wmc/XH8YubV+337n/DXrPSbzHTUsV87ZvX+l4vUSDratVBkgZPDq53NlzQe28KGbTefHI5CcPK0qehIZzDMU6wh9fkPpHdEhkm2H5E3muhvkrghdVH7CHnM97f7+agwGTXBkG785VBJ9LSWxHawbCkr+gIttAyFoedbeDwZYsHNrZ7uMxL5pM8H4aQO7Czqd7OzCl2ZJWaT72wBXvTL2s/ZK/s3Px6YUeZlpHzXH+94Es3ty6NYxgKZtaHsV/a0vuj3YHfYw9C1dfm9zB9oqKiALnofsQU+wBSqbjPrTN59BMvrbqzgOqSqCZHKvZqin1wjB32nVm/cf3GHI6Llm9SHFXZD3OH4k2JSKz1+1TRFK4f1DQqNK2pW1yKTY7fjDwGEjazq7kG9evzaJlV51Mf0njei7b8YYI0jzuUE+y73L7sfsqtsmb7mvDElpBx+murJpv3k6mdX4q5815zg3MVS/B/++uoHC7j6l5q9uqNu+k5jdnM7ERxPjxTGm43eFRT5V0RJS44n/6IbJWrRfOhybHdzHpM9Kk7Vel/29i5d9asrxVXb6go49Vl3SjLXIq57tVka3EpndZqBmjV1BKnwT23uzs9cXeU84ovUitqL+AZs0VRwFSLthb/b8afcUjZ9aLPclezQGD6izf5m3uzTZ/vylzi5TmtA2c8fBkYGlMP68CNwLnuh9TN6x0fvoMsL9HO/Q5y/Ih9O8w+ZWNO8MHXi3+EbpW6KYqmDbLv/VJVTrxaNW34zTMjEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEIhvwf8ArSfEVUJhVRMAAAAASUVORK5CYII=';
})();
