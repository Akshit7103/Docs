/**
 * OTC Compare & Match — Service Portal widget server.
 * Reads the target from the URL (?cf=<cashflow sys_id> preferred, else ?email=<email sys_id>) and
 * delegates to the CompareMatch Script Include's buildData() so the match + per-field logic stays in
 * one place (shared with the dashboard's classify()). Returns structured data; the Angular template
 * renders it. Opened from a dashboard row: /nfotcbsm?id=bsm_comparematch&cf=<sys_id>.
 */
(function () {
    var cm = new x_nose_nfotc_bsm.CompareMatch();
    data.logo = cm.LOGO;
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    // Header identity (name + avatar initials) from the ONE helper - was a hardcoded 'US' in the template.
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('User');
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('User');
    data.dashUrl = '/nfotcbsm?id=bsm_analystdashboard';

    var cfId = $sp.getParameter('cf') || '';
    var emId = $sp.getParameter('email') || '';

    // ── ACCESS GUARD ── this widget's server GlideRecord bypasses table ACLs, so the per-wizard isolation
    // must be enforced here. A non-manager/admin analyst may open Compare & Match ONLY for a cashflow/email
    // whose owning work-driver is assigned to them — otherwise a hand-typed ?cf=/?email= would expose another
    // team's settlement economics + the matched bank booking. Managers/admins pass (AccessGuard).
    var _ag = new x_nose_nfotc_bsm.AccessGuard();
    var _allowed = false;
    if (cfId) { var _cg = new GlideRecord('x_nose_nfotc_bsm_cashflow'); _allowed = _cg.get(cfId) && _ag.canViewCashflow(_cg); }
    // Owning wizard = wiz_extracted OR wiz_assigned — a claimed-but-not-yet-extracted mail (image/PDF/partial/
    // SSI, exactly the ?email= case) has only wiz_assigned set, so keying on wiz_extracted alone would wrongly
    // bounce its assigned analyst from their own mail.
    else if (emId) { var _eg = new GlideRecord('x_nose_nfotc_bsm_email'); _allowed = _eg.get(emId) && _ag.canViewWizard('' + (_eg.getValue('wiz_extracted') || _eg.getValue('wiz_assigned'))); }
    if ((cfId || emId) && !_allowed) {
        data.redirect = '/nfotcbsm?id=bsm_work_drivers';
        data.hasTarget = false; data.cmp = { found: false };
        return;
    }

    data.hasTarget = !!(cfId || emId);
    data.cmp = data.hasTarget ? cm.buildData(cfId, emId) : { found: false };
})();
