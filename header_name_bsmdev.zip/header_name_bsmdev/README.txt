HEADER NAME / INITIALS FIX for Nomura bsmdev  (2026-09-15)
Problem: the console header showed "Mahajan, Akshit (Operations/IN)" with initials "M(" because Nomura's directory
stores names as "Last, First (Dept/Region)". Fix: one helper in the AccessGuard Script Include cleans the name
("Akshit Mahajan", initials "AM"); the six header widgets read from it.

WHERE TO PASTE (bsmdev, scope: the BSM app)
 0_AccessGuard_SCRIPT_INCLUDE.js -> System Definition > Script Includes > "AccessGuard" (x_nose_nfotc_bsm) > Script field. PASTE THIS FIRST.
 1_work_drivers_SERVER.js        -> Service Portal > Widgets > OTC Work Drivers        (nfotcbsm-work-drivers)      > Server script
 2_manager_dashboard_SERVER.js   -> ... > OTC Manager Dashboard   (nfotcbsm-manager)           > Server script
 3_wizard_list_SERVER.js         -> ... > OTC Wizard List         (nfotcbsm-wizard-list)       > Server script
 4_wizard_builder_SERVER.js      -> ... > OTC Wizard Builder      (nfotcbsm-wizard-builder)    > Server script
 5_audit_view_SERVER.js          -> ... > OTC Audit Trail         (nfotcbsm-audit)             > Server script
 6_llm_usage_SERVER.js           -> ... > OTC AI Usage & Cost     (nfotcbsm-llm-usage)         > Server script
Save the old field content of each before pasting (restore = paste it back).

NOTE: files 2-5 are the CURRENT bsm versions, so they also bring the 12-Sep authorization hardening and today's
wizard-builder mandatory-field fix to bsmdev a little early. They rely only on AccessGuard methods that bsmdev
already has. Alternatively skip the widget pastes and let the final update-set export carry everything; then only
the header stays wrong until the export.
