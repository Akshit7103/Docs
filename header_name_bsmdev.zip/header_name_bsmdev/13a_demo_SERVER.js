/**
 * Demo page (Service Portal) — a self-contained "watch the AI read an email" experience for business
 * stakeholders. Upload an .eml -> it is parsed and shown -> click "Run AI extraction" -> the AI
 * (Extract Settlement Fields skill) returns the structured 13-field view per cashflow. No Compare &
 * Match, no workflow, no persisted cashflows — just the unstructured -> structured journey.
 *
 * The uploaded .eml is stored as an attachment on a throwaway x_nose_nfotc_bsm_email record (classification
 * 'demo', so it never shows on any dashboard) purely so the existing extractors can read it. Each new
 * upload deletes the previous throwaway record for this user.
 */
(function () {
    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    // Header identity (name + avatar initials) from the ONE helper - was a hardcoded 'US' in the template.
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('User');
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('User');
    data.homeUrl = '/nfotcbsm?id=bsm_work_drivers';
    data.stage = 'upload';
    data.aiDone = false;
    data.emailSysId = '';
    data.attId = '';
    data.fileName = '';
    data.mail = { to: '', from: '', cc: '', subject: '', body: '', received: '', attachment: '' };
    data.flows = [];
    data.cashflows = [];
    data.counterparty = '';
    data.cfTotal = 0;

    if (input && input.action === 'reset') { return; }

    // ---- Upload + parse ----
    if (input && input.action === 'extract' && input.emlText) {
        _cleanupPrior();
        var ids = _ingest(input.emlText, input.fileName || 'email.eml');
        if (!ids.email || !ids.att) { data.error = 'Could not read the uploaded file.'; return; }
        var res = new x_nose_nfotc_bsm.DemoExtractor().run(ids.att, ids.email, false);
        data.emailSysId = ids.email;
        data.attId = ids.att;
        data.fileName = input.fileName || 'email.eml';
        _applyMail(res);
        data.mail.attachment = _attName(ids.email, ids.att);
        data.flows = res.flows;
        data.cfTotal = res.flows.length;
        data.counterparty = res.counterparty;
        data.aiContent = res.aiContent;   // the exact text handed to the AI model
        data.stage = 'result';
        data.aiDone = false;
        return;
    }

    // ---- Run AI extraction ----
    if (input && input.action === 'run_ai' && input.emailSysId && input.attId) {
        var res2 = new x_nose_nfotc_bsm.DemoExtractor().run(input.attId, input.emailSysId, true);
        data.emailSysId = input.emailSysId;
        data.attId = input.attId;
        data.fileName = input.fileName || 'email.eml';
        _applyMail(res2);
        data.mail.attachment = _attName(input.emailSysId, input.attId);
        data.counterparty = res2.counterparty;
        data.cashflows = res2.cashflows;
        data.cfTotal = res2.cashflows.length;
        data.aiStatus = res2.aiStatus;
        data.flows = res2.flows;
        data.stage = 'result';
        data.aiDone = true;
        return;
    }

    // ---------------- helpers ----------------
    function _applyMail(res) {
        data.mail.to = res.mail.to; data.mail.from = res.mail.from; data.mail.cc = res.mail.cc;
        data.mail.subject = res.mail.subject; data.mail.body = res.mail.body;
        data.mail.received = _fmtReceived(res.mail.date);
    }

    // Create a throwaway email record + attach the raw .eml text so the extractors can read it.
    function _ingest(text, fileName) {
        var eg = new GlideRecord('x_nose_nfotc_bsm_email');
        eg.initialize();
        eg.setValue('name', fileName);
        eg.setValue('source', 'DemoUpload');
        eg.setValue('classification', 'demo'); // NOT 'relevant' -> hidden from every dashboard
        var eid = eg.insert();
        if (!eid) { return { email: '', att: '' }; }
        var att = '';
        try { att = '' + new GlideSysAttachment().write(eg, fileName, 'message/rfc822', '' + text); } catch (e) { gs.warn('[demo] write: ' + e); }
        return { email: '' + eid, att: att };
    }

    function _cleanupPrior() {
        var prev = new GlideRecord('x_nose_nfotc_bsm_email');
        prev.addQuery('source', 'DemoUpload');
        prev.addQuery('sys_created_by', gs.getUserName());
        prev.query();
        while (prev.next()) { prev.deleteRecord(); } // deleting the record cascades its attachments
    }

    // Name of the materialised spreadsheet attachment, if any (the .eml itself is excluded).
    function _attName(emailSysId, emlAttId) {
        var ag = new GlideRecord('sys_attachment');
        ag.addQuery('table_name', 'x_nose_nfotc_bsm_email');
        ag.addQuery('table_sys_id', emailSysId);
        ag.addQuery('sys_id', '!=', emlAttId);
        ag.query();
        var names = [];
        while (ag.next()) { names.push(ag.getValue('file_name')); }
        return names.join(', ');
    }

    // "Wed, 10 Jun 2026 16:01:13 -0000" -> "10-06-2026 16:01:13"
    function _fmtReceived(s) {
        s = '' + (s || '');
        var m = s.match(/(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})\s+(\d{2}:\d{2}:\d{2})/);
        if (!m) { return s; }
        var mon = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
            .indexOf(m[2].toLowerCase()) + 1;
        var mm = (mon < 10 ? '0' : '') + mon;
        var dd = (('' + m[1]).length < 2 ? '0' : '') + m[1];
        return dd + '-' + mm + '-' + m[3] + ' ' + m[4];
    }
})();
