/**
 * Work drivers — the post-login landing page. ROLE-BASED, driven by the APP roles (not the built-in
 * admin role), so a platform admin who is not a manager is treated as an analyst here:
 *   - Manager (x_nose_nfotc_bsm.manager) -> redirected to the Manager Dashboard (client).
 *   - Analyst (everyone else)        -> ONLY the published work-drivers ASSIGNED to them by a manager.
 */
(function () {
    // EXPLICIT role check — gs.hasRole('x_nose_nfotc_bsm.manager') is TRUE for every admin, so we inspect
    // the user's actual granted roles instead (a platform admin who is not a manager stays an analyst).
    function hasExplicitRole(roleName) {
        try {
            var roles = gs.getUser().getRoles();
            if (!roles) { return false; }
            for (var i = 0; i < roles.length; i++) { if (('' + roles[i]) === roleName) { return true; } }
        } catch (e) { /* fall through */ }
        return false;
    }

    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('Analyst');

    // View-as toggle — for approved demo operators (x_nose_nfotc_bsm.demo_users): switch Manager/Analyst view WITHOUT
    // changing real roles (session-scoped). Everyone else is unaffected.
    var isTestUser = new x_nose_nfotc_bsm.AccessGuard().isDemoUser();
    if (isTestUser && input && input.action === 'set_view') {
        gs.getSession().putClientData('nfotc_view_as', input.viewAs === 'manager' ? 'manager' : 'analyst');
    }
    var viewAs = isTestUser ? ('' + (gs.getSession().getClientData('nfotc_view_as') || '')) : '';

    var isAdmin = gs.hasRole('admin');
    var isManager = isTestUser ? (viewAs === 'manager') : hasExplicitRole('x_nose_nfotc_bsm.manager'); // admin alone is NOT a manager
    data.isManager = isManager;
    data.isAdmin = isAdmin;
    data.isTestUser = isTestUser;
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('Analyst');

    var uid = gs.getUserID();
    var cards = [];

    // This is the ANALYST surface only. Managers are redirected to the Manager Dashboard (client) and
    // never render this page's content, so we build NO cards for them (avoids the card-grid flash).
    if (!isManager) {
        var wz = new GlideRecord('x_nose_nfotc_bsm_wizard');
        wz.addQuery('status', 'published');
        wz.orderBy('name');
        wz.query();
        while (wz.next()) {
            var au = [];
            try { au = JSON.parse(wz.getValue('assigned_users') || '[]'); } catch (e) { au = []; }
            var mine = false;
            for (var i = 0; i < au.length; i++) { if (au[i].id === uid) { mine = true; break; } }
            if (!mine) { continue; }   // analysts see ONLY the workflows assigned to them
            cards.push({
                title: wz.getValue('name') || 'Untitled workflow',
                sub: 'Run this workflow',
                href: '/nfotcbsm?id=bsm_nfotc_wiz_dash&wiz=' + wz.getUniqueValue(),
                icon: 'ai'
            });
        }
    }

    data.cards = cards;
})();
