/**
 * OTC Dashboard — Service Portal widget SERVER script.
 * Faithful replica of the classic Outlook Tagging dashboard (TaggingDashboard.server.js).
 * Delegates all data prep to the same Script Include (TaggingDashboard.data()) so the two
 * dashboards can never drift; renders it in Angular (see dashboard.html/.scss/.client.js).
 */
(function () {
    // ── ACCESS GUARD ── TaggingDashboard.data() is a GLOBAL, cross-wizard list (every team's mails, with
    // counterparty + amount + trade id) and this widget's server GlideRecord bypasses table ACLs — so it is
    // MANAGER/ADMIN ONLY. An analyst's scoped view is their per-wizard board (bsm_nfotc_wiz_dash); redirect
    // them to the work-drivers landing rather than leaking the whole estate.
    var _ag = new x_nose_nfotc_bsm.AccessGuard();
    data.role = _ag.roleLabel();
    // Header identity (name + avatar initials) from the ONE helper - was a hardcoded 'US' in the template.
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('User');
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('User');
    if (!_ag.isManagerOrAdmin()) {
        data.redirect = '/nfotcbsm?id=bsm_work_drivers';
        data.stats = []; data.rows = []; data.counterparties = [];
        return;
    }
    var d = new x_nose_nfotc_bsm.TaggingDashboard().data();
    data.logo = d.logo;
    data.stats = d.stats;
    data.rows = d.rows;
    data.counterparties = d.counterparties;
})();
