/**
 * Published-wizard dashboard (Service Portal) — the block that appears on the work-driver landing once
 * a wizard is published. It IS the OTC Settlements Dashboard (delegates to TaggingDashboard.dataAi()),
 * but starts EMPTY: nothing shows until the analyst clicks "Sync now", which pulls the mailbox-drop
 * mails (already AI-extracted by the pipeline) into the board. The sync state is held per session so a
 * reload keeps the synced view. Rows link to the same Compare & Match + writeback case screen.
 */
(function () {
    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    // Header identity (name + avatar initials) from the ONE helper - was a hardcoded 'US' in the template.
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('User');
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('User');
    data.homeUrl = '/nfotcbsm?id=bsm_work_drivers';

    var wizId = $sp.getParameter('wiz') || (input && input.wizId) || '';
    // Recover the wizard from session when navigation dropped the ?wiz= param (e.g. coming back from a
    // case screen). The wiz-dashboard is ALWAYS per-wizard; without a wizId, TaggingDashboard.dataAi()
    // falls back to the GLOBAL view (every relevant mail, incl. CSG) — that is the bug being fixed here.
    if (!wizId) { wizId = '' + (gs.getSession().getClientData('nfotc_wiz_current') || ''); }
    if (wizId) { gs.getSession().putClientData('nfotc_wiz_current', wizId); }
    data.wizId = wizId;

    // ── BOARD-LEVEL ACCESS GUARD (centralised: x_nose_nfotc_bsm.AccessGuard) ──
    // The wiz board is per-wizard by definition — never render it (or the dataAi global fallback) without a
    // wizId; bounce to the landing page for EVERYONE (incl. admin). Otherwise managers/admins pass and an
    // analyst may open a board ONLY for a wizard assigned to them (a hand-typed ?wiz= URL is thus blocked).
    data.redirect = '';
    if (!wizId || !new x_nose_nfotc_bsm.AccessGuard().canViewWizard(wizId)) { data.redirect = '/nfotcbsm?id=bsm_work_drivers'; }
    if (data.redirect) {
        // Not permitted — return safe empty defaults so the template doesn't error during the redirect
        // flash, then stop building the board. The client navigates away on data.redirect.
        data.wizName = ''; data.isCsg = false; data.synced = false; data.progress = null; data.readOnly = true;
        data.stats = []; data.rows = []; data.counterparties = []; data.csgRows = []; data.csgStats = [];
        return;
    }

    // READ-ONLY mode — a manager/admin viewing a board they don't own as the assigned analyst, or an explicit
    // manager view opened from the dashboard (?ro=1). Read-only strips every state-changing control
    // (FR-UI-022: managers can't confirm/override/write-back). Only the assigned analyst may act.
    var _roParam = ('' + ($sp.getParameter('ro') || '')) === '1';
    data.readOnly = _roParam || !new x_nose_nfotc_bsm.AccessGuard().isAssignedAnalyst(wizId);

    data.wizName = 'OTC Settlements';
    // CSG mode: when this wizard is a CSG entity-data wizard (work-driver / name carries "csg"), the board
    // renders an ENTITY-BREAK view (EVE lookup by RDM id) instead of the OTC cashflow view. Detection is
    // string-based and off-path for OTC, so the OTC Settlements board is entirely unaffected.
    data.isCsg = false;
    var wizIdRules = '';
    if (wizId) {
        var wg = new GlideRecord('x_nose_nfotc_bsm_wizard');
        if (wg.get(wizId)) {
            data.wizName = wg.getValue('name') || 'OTC Settlements';
            // CSG detection is robust to the taxonomy: new wizards carry it as the "CSG" Service (OPS Client
            // Services -> Client Entity Data -> CSG); legacy ones carried "csg" in the work-driver/name/sub-bu.
            var sig = ((wg.getValue('service') || '') + ' ' + (wg.getValue('work_driver') || '') + ' ' + (wg.getValue('name') || '') + ' ' + (wg.getValue('sub_bu') || '')).toLowerCase();
            data.isCsg = sig.indexOf('csg') !== -1;
            wizIdRules = wg.getValue('id_rules') || '';
        }
    }

    var flagKey = 'wizsync_' + (wizId || 'default');
    data.syncInfo = null;
    if (input && input.action === 'sync' && wizId && !data.readOnly) {
        // "Sync now" RUNS THE WORKFLOW STUDIO FLOW — ASYNC. For each relevant mail it invokes the callable
        // subflow "OTC Settlement - Intake (Subflow)" in the BACKGROUND via sn_fd.FlowAPI (fire-and-forget),
        // so the request returns immediately and the mails process in parallel off the request thread.
        // Real progress is polled via 'sync_status'. Mails land at "Awaiting Confirmation" (HITL).
        var wgc = new GlideRecord('x_nose_nfotc_bsm_wizard');
        var activity = wgc.get(wizId) ? (wgc.getValue('activity') || '') : '';
        if (activity !== 'Compare & Match') {
            data.syncInfo = { queued: 0, unsupported: true, activity: activity };
        } else {
            var queued = 0, failed = 0, diag = '';
            // The ingest flow is upload-only now, so mails have NO classification yet — the SUBFLOW
            // classifies (and skips extraction for irrelevant). Run it on every mail this wizard hasn't
            // processed. Skip ones already extracted, or already processed (incl. classified-irrelevant).
            var rg = new GlideRecord('x_nose_nfotc_bsm_email');
            rg.orderBy('sys_created_on');
            rg.query();
            var wex = new x_nose_nfotc_bsm.WizardExtractor();
            while (rg.next()) {
                var eid = rg.getUniqueValue();
                if (rg.getValue('wiz_extracted') === wizId) { continue; }   // already EXTRACTED by this wizard (real success) — don't redo
                // OWNERSHIP GATE — the fix for cross-wizard sync. Only process mails that match THIS wizard's
                // Email-Identification rules; ingest-on-demand makes routing work on the first sync too.
                // Mails belonging to another wizard (or noise) are skipped entirely — never stamped, never
                // run — so clicking Sync on one board never touches the other board's mails.
                var route = wex.routeForWizard(wizId, eid);
                if (!route || route.classification !== 'relevant') { continue; }
                // NOTE: do NOT skip merely because composed_state==='done' — 'done' is set even when extraction
                // returned no rows, so a failed / empty mail MUST be retried on the next Sync (not skipped forever).
                var egr = new GlideRecord('x_nose_nfotc_bsm_email');
                if (!egr.get(eid)) { continue; }
                egr.setValue('composed_run', wizId); egr.setValue('composed_state', 'running'); egr.update();
                try {
                    // Reference input needs a GlideRecord. inBackground() = queue + return immediately.
                    // CSG runs through its OWN (dummy, demo-only) subflow; OTC through the real intake one.
                    var _subflow = data.isCsg ? 'x_nose_nfotc_bsm.csg_intake_subflow' : 'x_nose_nfotc_bsm.otc_intake_subflow';
                    sn_fd.FlowAPI.getRunner()
                        .subflow(_subflow)
                        .inBackground()
                        .withInputs({ email_record: egr })
                        .run();
                    queued++;
                } catch (efx) {
                    failed++; if (!diag) { diag = '' + efx; }
                    egr.setValue('composed_state', 'error'); egr.update();   // don't leave it stuck "running"
                }
            }
            data.syncInfo = { activity: activity, async: true, queued: queued, failed: failed, diag: diag };
        }
        gs.getSession().putClientData(flagKey, '1');
    }
    if (input && input.action === 'reset_sync' && !data.readOnly) { gs.getSession().clearClientData(flagKey); }
    var sessionFlag = ('' + (gs.getSession().getClientData(flagKey) || '')) === '1';

    // Live async progress for THIS wizard (polled by 'sync_status'; also computed on 'sync' + normal load).
    // A mail is DONE if it extracted (wiz_extracted===wizId) or its subflow finished (composed_state 'done');
    // RUNNING while its subflow is in flight; ERRORED if it failed to queue. Complete when running hits 0.
    data.progress = null;
    if (wizId) {
        var pDone = 0, pRunning = 0, pErr = 0, pMatched = 0;
        var pg = new GlideRecord('x_nose_nfotc_bsm_email');
        pg.addQuery('composed_run', wizId);
        pg.query();
        while (pg.next()) {
            pMatched++;
            var wx = pg.getValue('wiz_extracted'), cs = pg.getValue('composed_state');
            if (wx === wizId || cs === 'done') { pDone++; }
            else if (cs === 'error') { pErr++; }
            else if (cs === 'running') { pRunning++; }
            else { pDone++; }
        }
        if (data.isCsg) {
            // CSG SCANS THE WHOLE SHARED MAILBOX, then processes only its matches. Report the FULL scan:
            // every mail is evaluated against the wizard's rules; the ones it doesn't own are dismissed
            // instantly (counted done), and its matched mails extract in the background. So the bar reads
            // "N of <whole mailbox>", not "5 of 5".
            var tg = new GlideAggregate('x_nose_nfotc_bsm_email');
            tg.addAggregate('COUNT');
            tg.query();
            var scanTotal = tg.next() ? parseInt(tg.getAggregate('COUNT'), 10) : pMatched;
            var dismissed = Math.max(0, scanTotal - pMatched);   // scanned & not this wizard's -> done
            data.progress = { done: dismissed + pDone + pErr, running: pRunning, errored: pErr, target: scanTotal, matched: pMatched, complete: (pRunning === 0) };
        } else {
            data.progress = { done: pDone, running: pRunning, errored: pErr, target: pDone + pRunning + pErr, matched: pMatched, complete: (pRunning === 0) };
        }
    }

    // ── CSG ENTITY-BREAK BOARD ──────────────────────────────────────────────────────────────────────
    // Hardcoded EVE lookup for the POC (no AI, no extraction): pull the RDM id off each routed CSG mail
    // and resolve the entity record. Status is the headline column. This whole branch is CSG-only; the
    // OTC path below is never touched.
    if (data.isCsg) {
        // Hardcoded EVE directory (mirrors CSG_EVE_Reference.xlsx). Keyed by RDM id carried in the mail.
        var EVE = {
            '364469': { entity: 'ENT1', role: 'ISS,NLE,OBLG,TRAR,TROBO', shortName: 'ENT1', longName: 'Entity1', fullName: 'Entity1', country: 'GB', status: 'OPEN' },
            '372815': { entity: 'ENT2', role: 'ISS,NLE,OBLG,TRAR',       shortName: 'ENT2', longName: 'Entity2', fullName: 'Entity2', country: 'US', status: 'CLOSED' },
            '388104': { entity: 'ENT3', role: 'NLE,OBLG,TROBO',          shortName: 'ENT3', longName: 'Entity3', fullName: 'Entity3', country: 'SG', status: 'OPEN' },
            '395620': { entity: 'ENT4', role: 'ISS,NLE,OBLG,TRAR,TROBO', shortName: 'ENT4', longName: 'Entity4', fullName: 'Entity4', country: 'DE', status: 'CLOSED' },
            '402337': { entity: 'ENT5', role: 'ISS,NLE,OBLG,TROBO',      shortName: 'ENT5', longName: 'Entity5', fullName: 'Entity5', country: 'HK', status: 'OPEN' }
        };
        // The CSG mails are the ones carrying this wizard's identifier keyword in the subject (NLUX by
        // default) — robust to the shared classification field flip-flopping between wizards.
        var kw = 'NLUX';
        try { var lbls = JSON.parse(wizIdRules || '[]'); if (lbls[0] && lbls[0].subject) { kw = '' + lbls[0].subject; } } catch (eKw) { /* default */ }

        data.csgRows = [];
        var csgOpen = 0, csgClosed = 0, csgUnmatched = 0, csgProcessed = 0;
        var cg = new GlideRecord('x_nose_nfotc_bsm_email');
        cg.addQuery('mail_subject', 'CONTAINS', kw);
        cg.orderBy('sys_created_on');
        cg.query();
        while (cg.next()) {
            // "This wizard synced these mails" marker — set only by THIS board's Sync loop. OTC's Sync
            // ingests (parses) the CSG mails to route/exclude them, but the ownership gate never stamps
            // composed_run on them, so it can't make the CSG board look synced.
            if (cg.getValue('composed_run') === wizId) { csgProcessed++; }
            var subj = cg.getValue('mail_subject') || '';
            var body = cg.getValue('mail_body') || '';
            // RDM id: trailing number in the subject, else ORG_RDM_ID in the body, else any 5–7 digit run.
            var m = subj.match(/(\d{5,7})\s*$/) ||
                    body.match(/ORG[_ ]?RDM[_ ]?ID\D{0,20}(\d{5,7})/i) ||
                    subj.match(/(\d{5,7})/);
            var rdm = m ? m[1] : '';
            var e = EVE[rdm] || null;
            if (e && e.status === 'OPEN') { csgOpen++; }
            else if (e && e.status === 'CLOSED') { csgClosed++; }
            else { csgUnmatched++; }
            data.csgRows.push({
                mailId: cg.getValue('name'),
                rdm: rdm || '-',
                entity: e ? e.entity : '-',
                role: e ? e.role : '-',
                shortName: e ? e.shortName : '-',
                longName: e ? e.longName : '-',
                fullName: e ? e.fullName : '-',
                country: e ? e.country : '-',
                status: e ? e.status : 'NOT FOUND',
                matched: !!e,
                // display-only mail context for the detail panel (does not affect routing/EVE lookup)
                subject: subj,
                from: cg.getValue('mail_from') || '',
                to: cg.getValue('mail_to') || '',
                cc: cg.getValue('mail_cc') || '',
                body: body
            });
        }
        data.csgStats = [
            { label: 'Entity Breaks', num: data.csgRows.length, numCls: 'n-blue' },
            { label: 'Open', num: csgOpen, numCls: 'n-green' },
            { label: 'Closed', num: csgClosed, numCls: 'n-amber' },
            { label: 'Unresolved', num: csgUnmatched, numCls: (csgUnmatched ? 'n-red' : '') }
        ];
        // Synced ONLY when CSG's own Sync has run: a CSG mail carries composed_run === wizId (persists),
        // OR a sync is in flight, OR the session flag is set (immediate post-click). Merely having NLUX
        // mails in the table (e.g. ingested by OTC's Sync) does NOT count — so the CSG board stays on the
        // "Nothing run yet" empty state until the user clicks Sync on THIS board.
        var csgInFlight = !!(data.progress && data.progress.running > 0);
        data.synced = (csgProcessed > 0) || csgInFlight || sessionFlag;
        // OTC arrays stay empty in CSG mode.
        data.stats = []; data.rows = []; data.counterparties = [];
        return;
    }

    // PERSISTENCE: the board is "synced" if this wizard already has extracted mails in the DB (so it
    // survives leaving and returning to the page), OR a sync is currently in flight, OR the session flag
    // is set (immediate post-click). No longer session-only — a reload/navigation keeps the results.
    var d = new x_nose_nfotc_bsm.TaggingDashboard().dataAi(wizId, data.readOnly);
    var hasRows = !!(d && d.rows && d.rows.length);
    var inFlight = !!(data.progress && data.progress.running > 0);
    data.synced = hasRows || inFlight || sessionFlag;
    data.funnel = null;
    if (data.synced) {
        // scope the board to only the mails THIS wizard has extracted with its own field prompts
        data.stats = d.stats;
        data.rows = d.rows;
        data.counterparties = d.counterparties;

        // ── Mail pipeline funnel: Processed → Relevant → Extracted. Makes the mail flow transparent so
        // nothing feels "lost" — every scanned mail is accounted for, and the drop-off at each stage is
        // explicit. All cheap COUNT aggregates on the email table.
        //   Processed = the whole shared mailbox this wizard's Sync scanned/evaluated.
        //   Relevant  = mails this driver CLAIMED via its Email-Identification rules (composed_run = wizId,
        //               or already extracted by it) — i.e. relevant + owned.
        //   Extracted = mails that produced ≥1 cashflow (wiz_extracted = wizId).
        function _count(gr) { gr.addAggregate('COUNT'); gr.query(); return gr.next() ? (parseInt(gr.getAggregate('COUNT'), 10) || 0) : 0; }
        var _fp = new GlideAggregate('x_nose_nfotc_bsm_email');
        var _processed = _count(_fp);
        var _fr = new GlideAggregate('x_nose_nfotc_bsm_email');
        _fr.addQuery('composed_run', wizId).addOrCondition('wiz_extracted', wizId);   // relevant + owned (⊇ extracted)
        var _relevant = _count(_fr);
        var _fe = new GlideAggregate('x_nose_nfotc_bsm_email');
        _fe.addQuery('wiz_extracted', wizId);
        var _extracted = _count(_fe);
        data.funnel = {
            processed: _processed,
            relevant: _relevant,
            extracted: _extracted,
            filtered: Math.max(0, _processed - _relevant),   // scanned but not this driver's / not relevant
            pending: Math.max(0, _relevant - _extracted)     // claimed but not yet extracted (failed / in-flight → retried next Sync)
        };
    } else {
        data.stats = [];
        data.rows = [];
        data.counterparties = [];
    }
})();
