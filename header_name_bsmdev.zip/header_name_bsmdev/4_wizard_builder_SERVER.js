/**
 * Wizard Builder — 5-step config builder (server).
 * Provides the option catalogs + preconfigured field catalog + target-field lists, loads an
 * existing wizard when ?copy / ?edit is present, and persists on Save-as-draft / Publish.
 * All step state lives on the CLIENT; the only server round-trips are the terminal save/publish
 * (which then navigate back to the list), so the working model is never lost mid-build.
 */
(function () {
    data.logo = new x_nose_nfotc_bsm.CompareMatch().LOGO;
    data.name = new x_nose_nfotc_bsm.AccessGuard().userDisplayName('Analyst');

    // ── ACCESS GUARD (centralised: x_nose_nfotc_bsm.AccessGuard) ──
    // Wizard authoring (create/edit/publish work-drivers) is a MANAGER surface. SP widget server scripts
    // run server-side and BYPASS the manager-only wizard ACL, so authorisation is enforced HERE. Because
    // this returns first, it guards page load AND every action below (test / run_extract / save_draft /
    // publish). Uses REAL granted roles (not the header 'view-as' label) so a view toggle cannot grant access.
    if (!new x_nose_nfotc_bsm.AccessGuard().isManagerOrAdmin()) { data.redirect = '/nfotcbsm?id=bsm_work_drivers'; return; }

    // Header role label — the Wizard Builder is the MANAGER authoring surface, so show the user's real
    // functional role (Manager first; a pure platform admin -> Administrator; otherwise Analyst). Never
    // hardcode 'Admin'. Mirrors the Manager Dashboard, incl. the test-user view-as toggle, so the label
    // is consistent across the manager surfaces.
    function hasExplicitRole(roleName) {
        try {
            var roles = gs.getUser().getRoles();
            if (roles) { for (var i = 0; i < roles.length; i++) { if (('' + roles[i]) === roleName) { return true; } } }
        } catch (e) { /* fall through */ }
        return false;
    }
    var isTestUser = new x_nose_nfotc_bsm.AccessGuard().isDemoUser();   // demo operators (x_nose_nfotc_bsm.demo_users)
    var viewAs = isTestUser ? ('' + (gs.getSession().getClientData('nfotc_view_as') || '')) : '';
    var isManager = isTestUser ? (viewAs === 'manager') : hasExplicitRole('x_nose_nfotc_bsm.manager');
    data.role = new x_nose_nfotc_bsm.AccessGuard().roleLabel();
    // Avatar initials from the display name (was hardcoded 'US').
    data.initials = new x_nose_nfotc_bsm.AccessGuard().userInitials('Analyst');

    // ---- option catalogs ----
    // BU -> Sub-BU -> Activity -> Work Driver cascade comes from the shared taxonomy (CompareMatch).
    var _cm = new x_nose_nfotc_bsm.CompareMatch();
    data.cat = {
        taxonomy: _cm.taxonomy(),
        inputFormats: ['Email', 'PDF', 'Excel'],
        ingestionTypes: ['Mail', 'API', 'File Drop', 'Manual'],
        mailboxes: ['email1@outlook.com', 'email2@outlook.com', 'settlements@bank.com'],
        frequencies: ['Real-time', 'Hourly', 'Daily'],
        targetSystems: ['System 1', 'System 2', 'PCM'],
        // Write-back actions offered per Compare & Match outcome (unfilled by default in the wizard).
        writebackActions: ['Send to NEWS', 'Reply to Counterparty', 'Reply to Middle Office'],
        // Skill (activity) options on the Define screen — the pipeline the manager picks. Only
        // Compare & Match is wired; Reconcile / Validation are demo placeholders with their own steps.
        activityOptions: ['Compare & Match', 'Reconcile', 'Validation'],
        // Preconfigured input fields — name + the extraction prompt (aligned with the production
        // "Extract Settlement Fields" skill) + an example VALUE + data type. Mandatory fields first,
        // optional below. Counterparty is intentionally NOT here — it is derived from the sender, not
        // extracted by the AI.
        fieldCatalog: [
            // ---- CSG mandatory: the RDM id keys the EVE-directory lookup (extract-only; placeholder for now) ----
            {
                name: 'RDM ID', type: 'string', mandatory: true,
                prompt: "Extract the RDM entity identifier for this notification — the reference-data master id used to resolve the entity in the EVE directory. It usually appears at the end of the subject line after the final ' - ', and inside the email body labelled 'ORG_RDM_ID' or 'RDM ID'. It is a 5–7 digit number. Return the digits only. If it is genuinely absent, return an empty string.",
                value: '364469',
                examples: ['364469', '372815', '388104']
            },
            // ---- mandatory (MASTER prompt + 3 worked examples, grounded in the real counterparty mails:
            //      pipe tables, free-form prose, SWIFT MT :32A:/:72:, key/value blocks, "AUD P" shorthand) ----
            {
                name: 'Value Date', type: 'string', mandatory: true,
                prompt: "Extract the settlement / value date for this cashflow. It may appear under a value-date column or label, after the word 'value', in a key/value line, inside a SWIFT date-and-amount field, or — only when the body contains none — in the subject line. The source date may be written in ISO, day-first, or day-month-name form, or as a compact SWIFT date; interpret whichever is present. Always return the date in ISO format YYYY-MM-DD. If it is genuinely absent, return an empty string.",
                value: '2026-06-13',
                examples: ['2026-06-13', '2026-06-14', '2026-06-05']
            },
            {
                name: 'Amount', type: 'float', mandatory: true,
                prompt: "Extract the settlement amount for this cashflow — the cash amount to settle, not the trade notional. The column may be labelled Amount, Flow Amount or Quantity; that value is the settlement amount. Strip any currency symbol and thousands separators. Where a comma is used as the decimal separator, convert it to a dot. Preserve the sign — negative amounts must stay negative. Return the number only, using a dot as the decimal separator. If it is absent, return an empty string.",
                value: '1497447.18',
                examples: ['1497447.18', '690397.75', '-2309184.24']
            },
            {
                name: 'Currency', type: 'string', mandatory: true,
                prompt: "Extract the settlement currency for this cashflow as a three-letter ISO 4217 code. It may appear under a currency column or label, in a key/value line, embedded inside a SWIFT date-and-amount field, or as the first token of a shorthand amount line. Return the uppercase three-letter code only. If it is absent, return an empty string.",
                value: 'EUR',
                examples: ['EUR', 'SGD', 'AUD']
            },
            {
                name: 'Direction', type: 'string', mandatory: true,
                prompt: "Extract the settlement direction for this cashflow from the counterparty's stated point of view — return exactly 'Pay' or 'Receive'. Normalise single-letter indicators, SWIFT direction tags, and combined Pay/Receive columns to the full word. In shorthand lines the direction indicator follows the currency. If the email states no direction (for example a fund or quantity table with no Pay/Receive column), return an empty string — do not infer it from the amount's sign.",
                value: 'Pay',
                examples: ['Pay', 'Receive', 'Pay']
            },
            // ---- optional ----
            // ---- optional (MASTER-style prompt + 3 grounded examples, from the real counterparty mails) ----
            { name: 'Nomura Entity', type: 'string', mandatory: false,
              prompt: "Extract the Nomura booking entity for this cashflow — the internal legal entity / branch on Nomura's side (the recipient side of the correspondence), NOT the counterparty. It may appear after a label such as 'Entity', 'Nomura Entity' or 'Bank', or written as 'BANK <city>' (e.g. 'BANK London', 'BANK Singapore'), or in an 'Entity=' key/value line. Return the entity name only. If the email does not name a Nomura entity, return an empty string — do not guess.",
              value: 'BANK London', examples: ['BANK London', 'BANK Singapore', 'BANK Tokyo'] },
            { name: 'Product', type: 'string', mandatory: false,
              prompt: "Extract the product / instrument type for this cashflow. It usually appears on a line labelled 'Product' (sometimes 'Instrument' or 'Product Type'), e.g. 'Equity-Linked Note', 'FX Forward', 'Credit Default Swap', 'NDF', 'Interest Rate Swap'. Return the product name exactly as written. If no product is stated, return an empty string.",
              value: 'Equity-Linked Note', examples: ['Equity-Linked Note', 'FX Forward', 'Credit Default Swap'] },
            { name: 'Trade Reference', type: 'string', mandatory: false,
              prompt: "Extract the counterparty's trade / deal reference for THIS cashflow. It typically appears on a line labelled 'Reference' (sometimes 'Trade Ref', 'Deal Ref' or 'Our Ref') and is usually a 9-digit number. When the email lists multiple cash flows, take the reference from the same block as this cashflow. Return the reference token only. If none is present, return an empty string.",
              value: '345927053', examples: ['345927053', '344803556', '352338792'] },
            { name: 'Trade Date', type: 'string', mandatory: false,
              prompt: "Extract the trade / execution date for this cashflow — the date the trade was dealt, which is DISTINCT from the settlement / value date. Look for a label such as 'Trade Date', 'Deal Date' or 'Execution Date'. Interpret whatever date format is present and always return ISO format YYYY-MM-DD. Many settlement mails do not state a trade date; if it is genuinely absent, return an empty string — do NOT substitute the value date.",
              value: '2026-06-10', examples: ['2026-06-10', '2026-06-05', ''] },
            { name: 'SSI Bank / BIC', type: 'string', mandatory: false,
              prompt: "Extract the settlement agent bank and its BIC from the settlement-instruction (SSI) block. It usually appears on a line labelled 'SSI Bank (BIC)', 'Agent Bank' or 'Correspondent'. Return the bank name together with the BIC in parentheses exactly as written, e.g. 'AGENT BANK 7 (AGGBUS3N)'. If the email carries no SSI block, return an empty string.",
              value: 'AGENT BANK 7 (AGGBUS3N)', examples: ['AGENT BANK 7 (AGGBUS3N)', 'AGENT BANK 5 (AGEBGB22)', 'AGENT BANK 1 (AGABUS33)'] },
            { name: 'SSI Account', type: 'string', mandatory: false,
              prompt: "Extract the settlement account number from the SSI block for this cashflow — usually the line labelled 'SSI Account' or 'Account'. It is typically a 10-digit number. Return the digits only. If no SSI account is given, return an empty string.",
              value: '1874730946', examples: ['1874730946', '8052701989', '1500631843'] },
            { name: 'SSI Beneficiary / BIC', type: 'string', mandatory: false,
              prompt: "Extract the beneficiary and its BIC from the settlement-instruction block — usually the line labelled 'Beneficiary (BIC)' or 'Beneficiary'. Return the beneficiary name together with the BIC in parentheses exactly as written, e.g. 'Counterparty8 (CPTYCA2L)'. If no beneficiary is stated, return an empty string.",
              value: 'Counterparty8 (CPTYCA2L)', examples: ['Counterparty8 (CPTYCA2L)', 'Counterparty7 (CPTYAU2L)', 'Counterparty (DEMOCP2L)'] },
            { name: 'SSI Intermediary', type: 'string', mandatory: false,
              prompt: "Extract the intermediary / correspondent bank and its BIC from the settlement-instruction block, if present — usually labelled 'Intermediary (BIC)', 'Intermediary' or 'Correspondent'. Return the name with the BIC in parentheses exactly as written. Many mails have no intermediary line; if it is genuinely absent, return an empty string.",
              value: '', examples: ['INTERMEDIARY BANK 2 (INTBUS33)', 'CORRESPONDENT BANK (CORRGB22)', ''] }
        ],
        // Target-system column names available for mapping.
        targetFields: {
            'System 1': ['trade_ref', 'cpty', 'notional_amt', 'ccy_pair', 'rate', 'value_dt', 'trade_dt', 'side'],
            'System 2': ['tradeId', 'counterparty', 'notional', 'currencyPair', 'price', 'valueDate', 'tradeDate', 'buySell'],
            'PCM': ['cashflow_id', 'counterparty_entity', 'amount', 'currency', 'rate', 'value_date', 'trade_date', 'direction']
        },
        // CSG target systems + their identifier columns — the RDM id maps to the system's "rdm id" column.
        targetSystemsCsg: ['EVE', 'Target 1', 'Target 2'],
        targetFieldsCsg: {
            'EVE': ['rdm id', 'entity', 'role', 'short_name', 'long_name', 'full_name', 'country', 'status'],
            'Target 1': ['rdm id', 'entity', 'status'],
            'Target 2': ['rdm id', 'entity', 'status']
        }
    };

    // ---- Field-list normalisation: the ONE place the persisted input_fields shape is decided ----------------
    // The mandatory set comes from the catalog: OTC = Value Date / Amount / Currency / Direction, CSG = RDM ID.
    // Whatever a client sends (or an older builder stored), the persisted list guarantees:
    //   * every mandatory field is present, first, in fixed order, and LOCKED (custom:false, mapExclude:false,
    //     catalog prompt when blank) -- a mandatory field can never be renamed, blanked or treated as custom;
    //   * a custom row whose name matches a catalog field (case-insensitive) BECOMES that catalog field;
    //   * names are trimmed and de-duplicated case-insensitively; blank / '__custom__' placeholders are dropped;
    //   * the OTHER mode's mandatory fields are dropped (OTC <-> CSG swap the locked set).
    // Applied on SAVE and on LOAD (self-heal), so a poisoned record cannot survive either path.
    var OTC_MANDATORY = ['Value Date', 'Amount', 'Currency', 'Direction'];
    var CSG_MANDATORY = ['RDM ID'];
    function _fkey(n) { return ('' + (n || '')).trim().toLowerCase(); }
    function _catByKey(k) {
        var fc = data.cat.fieldCatalog || [];
        for (var i = 0; i < fc.length; i++) { if (_fkey(fc[i].name) === k) { return fc[i]; } }
        return null;
    }
    // Same CSG detection as the client (Service = CSG, or legacy 'CSG' in Sub-BU / Work driver).
    function _isCsgModel(service, subBu, workDriver) {
        if (('' + (service || '')).toUpperCase() === 'CSG') { return true; }
        return ((('' + (subBu || '')) + ' ' + ('' + (workDriver || ''))).toUpperCase()).indexOf('CSG') !== -1;
    }
    function _cleanExamples(list) {
        var exs = [], fex = (list instanceof Array) ? list : [];
        for (var xi = 0; xi < fex.length; xi++) {
            var ev = fex[xi];
            if (ev && typeof ev === 'object') { ev = ev.value; }   // migrate any old {input,value}
            if (ev !== null && ev !== undefined && ('' + ev) !== '') { exs.push('' + ev); }
        }
        return exs;
    }
    function _fromCatalog(cf) {
        return { name: cf.name, type: cf.type || 'string', prompt: cf.prompt || '', example: cf.example || '', value: cf.value || '', custom: false, mapExclude: false, examples: (cf.examples || []).slice() };
    }
    function _normaliseFields(fields, isCsg) {
        var mandNames = isCsg ? CSG_MANDATORY : OTC_MANDATORY, dropNames = isCsg ? OTC_MANDATORY : CSG_MANDATORY;
        var mandKeys = [], dropKeys = [], i;
        for (i = 0; i < mandNames.length; i++) { mandKeys.push(_fkey(mandNames[i])); }
        for (i = 0; i < dropNames.length; i++) { dropKeys.push(_fkey(dropNames[i])); }
        var byKey = {}, order = [], src = (fields instanceof Array) ? fields : [];
        for (i = 0; i < src.length; i++) {
            var f = src[i] || {}, k = _fkey(f.name);
            if (!k || k === '__custom__' || dropKeys.indexOf(k) !== -1 || byKey[k]) { continue; }
            var cf = _catByKey(k), isMand = mandKeys.indexOf(k) !== -1;
            byKey[k] = {
                name: cf ? cf.name : ('' + f.name).trim(),
                type: f.type || (cf && cf.type) || 'string',
                prompt: ('' + (f.prompt || '')) || (cf ? (cf.prompt || '') : ''),
                example: '' + (f.example || ''), value: '' + (f.value || ''),
                custom: cf ? false : !!f.custom,
                mapExclude: isMand ? false : !!f.mapExclude,
                examples: _cleanExamples(f.examples)
            };
            order.push(k);
        }
        var out = [];
        for (i = 0; i < mandKeys.length; i++) {
            if (!byKey[mandKeys[i]]) { var mc = _catByKey(mandKeys[i]); if (mc) { byKey[mandKeys[i]] = _fromCatalog(mc); } }
            if (byKey[mandKeys[i]]) { out.push(byKey[mandKeys[i]]); }
        }
        for (i = 0; i < order.length; i++) { if (mandKeys.indexOf(order[i]) === -1) { out.push(byKey[order[i]]); } }
        return out;
    }
    // Change-detection signature for the self-heal (only the persisted, behaviour-relevant attributes).
    function _fieldsSig(list) {
        var s = [], src = (list instanceof Array) ? list : [];
        for (var i = 0; i < src.length; i++) {
            var f = src[i] || {};
            s.push(['' + (f.name || ''), !!f.custom, !!f.mapExclude, f.type || 'string', '' + (f.prompt || '')]);
        }
        return JSON.stringify(s);
    }

    function defaultModel() {
        return {
            id: '', name: '', description: '', bu: '', subBu: '', service: '',
            workDriver: '', activity: '',
            inputFormat: 'Email', ingestionType: 'Mail', mailbox: '', frequency: 'Real-time',
            labels: [],                          // [{name, context, keywords, senders, subject, exclusions}]
            fields: [],                          // [{name, type, prompt, example, value, custom, matchMode, fuzzyPct, tolerance}]
            targets: [{ system: '', map: {} }],  // [{system, map: {fieldName: targetField}}]
            // Outlook Tagging — one row per preconfigured stage; manager fills the tag.
            tagging: [
                { stage: 'Default', tag: '' },
                { stage: 'Extraction Confirmed', tag: '' },
                { stage: 'Review Confirmed', tag: '' },
                { stage: 'Resolved', tag: '' },
                { stage: 'Escalated', tag: '' }
            ],
            // Analyst Writeback — the 3 fixed match outcomes; each holds a LIST of configured actions
            // (unfilled by default — the manager adds one or more in the Write-back step).
            writeback: [
                { scenario: 'Matched', actions: [] },
                { scenario: 'Mismatch', actions: [] },
                { scenario: 'No Match', actions: [] }
            ],
            tolerances: {},                      // { rel_tol, abs_tol, vd_tol_days, t2_amt_abs, t2_amt_rel } — blank = inherit system default
            status: 'draft', version: 'v1'
        };
    }

    // ---- activity step-template registry ----
    // The step SEQUENCE for a (work-driver / activity) is PRE-CODED, not composed by the manager. Once
    // an activity is chosen on the Define screen, its steps are revealed (read-only); the manager only
    // configures each step's values below. Adding a new activity's sequence is a DEVELOPER task.
    // (Only "Compare & Match" is defined for now — other activities show "not defined yet".)
    data.cat.stepTemplates = {
        'Compare & Match': [
            { n: 1, name: 'Email Ingestion', desc: 'Pull the email from the configured mailbox / source.' },
            { n: 2, name: 'Email Identification', desc: 'Classify the email and keep only the in-scope ones.' },
            { n: 3, name: 'Extract Counterparty', desc: 'Derive the counterparty from the sender directory.' },
            { n: 4, name: 'Extract Fields', desc: 'Extract the settlement fields using the configured AI prompts.' },
            { n: 5, name: 'Compare & Match', desc: 'Match the extracted fields against the target system.' },
            { n: 6, name: 'Route / Write-back', desc: 'Surface the outcome to the analyst for review & write-back.' }
        ],
        // ---- DEMO PLACEHOLDERS: Reconcile / Validation reveal their own step sequence on Define, but are
        // NOT wired to a runtime pipeline yet (only Compare & Match runs). Different steps per skill. ----
        'Reconcile': [
            { n: 1, name: 'Email Ingestion', desc: 'Pull the email from the configured mailbox / source.' },
            { n: 2, name: 'Email Identification', desc: 'Classify the email and keep only the in-scope ones.' },
            { n: 3, name: 'Extract Positions', desc: 'Extract the positions / balances to reconcile.' },
            { n: 4, name: 'Load Ledger', desc: 'Load the internal ledger records for the value date.' },
            { n: 5, name: 'Reconcile', desc: 'Reconcile the extracted positions against the ledger and flag breaks.' },
            { n: 6, name: 'Route Breaks', desc: 'Route the reconciliation breaks to the analyst.' }
        ],
        'Validation': [
            { n: 1, name: 'Email Ingestion', desc: 'Pull the email from the configured mailbox / source.' },
            { n: 2, name: 'Email Identification', desc: 'Classify the email and keep only the in-scope ones.' },
            { n: 3, name: 'Extract Fields', desc: 'Extract the fields to validate using the configured AI prompts.' },
            { n: 4, name: 'Validate', desc: 'Validate the extracted fields against the business rules.' },
            { n: 5, name: 'Report', desc: 'Report the validation outcome to the analyst.' }
        ]
    };
    // CSG entity-data pipeline — different sequence: extract the RDM id, resolve it in EVE, surface the
    // entity + status. No counterparty derivation, no compare/match, no write-back.
    data.cat.stepTemplatesCsg = [
        { n: 1, name: 'Email Ingestion', desc: 'Pull the entity-data email from the configured mailbox / source.' },
        { n: 2, name: 'Email Identification', desc: 'Classify & route the CSG (NLUX) emails and keep only the in-scope ones.' },
        { n: 3, name: 'Extract RDM ID', desc: 'Extract the RDM id from the email using the configured AI prompt.' },
        { n: 4, name: 'Resolve in EVE', desc: 'Look up the RDM id in the EVE directory (entity, role, names, country, status).' },
        { n: 5, name: 'Review', desc: 'Surface the resolved entity and its status to the analyst.' }
    ];

    // ---- Compare & Match tolerances (step 5) — per-driver overrides + current SYSTEM defaults for placeholders.
    // Written to x_nose_nfotc_bsm_wizard.config_overrides (match.* keys) and read live by CompareMatch.loadConfig(wizId).
    var _cfg = new x_nose_nfotc_bsm.NfotcConfig();
    data.cat.tolerances = [
        // Tier 1 & 3 are EXACT (no tolerance) per FR-MTH-001/020 — only Tier 2 has tunable tolerances.
        { mkey: 'vd_tol_days', ckey: 'match.vd_tol_days', label: 'Value-date window (business days)', tier: 'Tier 2', step: '1', def: _cfg.getNumber('match.vd_tol_days', '', 2), hint: '+/- N BUSINESS days for the fuzzy value-date match (weekends skipped).' },
        { mkey: 't2_amt_abs', ckey: 'match.t2_amt_abs', label: 'Tier 2 amount tolerance', tier: 'Tier 2', step: '0.1', def: _cfg.getNumber('match.t2_amt_abs', '', 50.0), hint: 'Amount tolerance in currency units (FSD: "$50 equivalent" — FX normalization pending).' },
        { mkey: 'name_fuzzy_pct', ckey: 'match.name_fuzzy_pct', label: 'Fuzzy name-match threshold', tier: 'Tier 2', step: '0.01', def: _cfg.getNumber('match.name_fuzzy_pct', '', 0.85), hint: 'Similarity 0-1 for the counterparty name fuzzy match, e.g. 0.85.' }
    ];

    // ---- load existing (copy = clone, edit = same record) ----
    var copyId = $sp.getParameter('copy') || '';
    var editId = $sp.getParameter('edit') || '';
    var loadId = editId || copyId;
    data.mode = editId ? 'edit' : 'new';
    var model = defaultModel();
    if (loadId) {
        var g = new GlideRecord('x_nose_nfotc_bsm_wizard');
        if (g.get(loadId)) {
            model.name = editId ? g.getValue('name') : (g.getValue('name') + ' (copy)');
            model.description = g.getValue('description');
            model.bu = g.getValue('bu') || '';
            model.subBu = g.getValue('sub_bu') || '';
            model.service = g.getValue('service') || '';
            model.workDriver = g.getValue('work_driver');
            model.activity = g.getValue('activity') || 'Compare & Match';
            // Back-fill BU/Sub-BU/Service for wizards created before the current taxonomy so the cascade shows them.
            var _rt = _cm.resolveTaxonomy(model.bu, model.subBu, model.service, model.workDriver);
            model.bu = _rt.bu; model.subBu = _rt.subBu; model.service = _rt.service;
            model.inputFormat = g.getValue('input_format') || 'Email';
            model.ingestionType = g.getValue('ingestion_type') || 'Mail';
            model.mailbox = g.getValue('mailbox');
            model.frequency = g.getValue('frequency') || 'Real-time';
            try { model.labels = JSON.parse(g.getValue('id_rules') || '[]'); } catch (el) { model.labels = []; }
            try { model.fields = JSON.parse(g.getValue('input_fields') || '[]'); } catch (e) { model.fields = []; }
            // SELF-HEAL: normalise the stored field list against the catalog (mandatory fields locked + present, no
            // custom row shadowing a catalog field, no duplicates). If that changes anything, write it straight back,
            // so a record poisoned by an older builder is repaired the moment it is opened -- on every instance,
            // with no data-fix script. (A COPY leaves its source untouched: the new wizard gets the healed list on save.)
            var _healed = _normaliseFields(model.fields, _isCsgModel(model.service, model.subBu, model.workDriver));
            if (editId && _fieldsSig(_healed) !== _fieldsSig(model.fields)) {
                g.setValue('input_fields', JSON.stringify(_healed));
                g.update();
                gs.info('[wizard-builder] healed input_fields on wizard ' + g.getUniqueValue() + ' (' + g.getValue('name') + ')');
            }
            model.fields = _healed;
            try { var tg = JSON.parse(g.getValue('tagging') || '[]'); if (tg.length) { model.tagging = tg; } } catch (etg) { /* keep defaults */ }
            try { var wb = JSON.parse(g.getValue('writeback') || '[]'); if (wb.length) { model.writeback = wb; } } catch (ewb) { /* keep defaults */ }
            var tmap = {};
            try { tmap = JSON.parse(g.getValue('mapping') || '{}'); } catch (e2) { tmap = {}; }
            model.targets = [{ system: g.getValue('target_system') || '', map: tmap }];
            // Per-driver Compare & Match tolerances (config_overrides JSON, keyed match.* -> model key).
            model.tolerances = {};
            try {
                var _ov = JSON.parse(g.getValue('config_overrides') || '{}') || {};
                for (var _t = 0; _t < data.cat.tolerances.length; _t++) {
                    var _td = data.cat.tolerances[_t];
                    if (Object.prototype.hasOwnProperty.call(_ov, _td.ckey)) { model.tolerances[_td.mkey] = '' + _ov[_td.ckey]; }
                }
            } catch (etol) { model.tolerances = {}; }
            if (editId) { model.id = loadId; model.status = g.getValue('status') || 'draft'; model.version = g.getValue('version') || 'v1'; }
        }
    }
    data.initModel = model;
    data.startStep = parseInt($sp.getParameter('step'), 10) || 1;

    // ---- Test a single field's extraction against sample input, via direct Chinou (GenericFieldExtractor) ----
    // Prompt-driven: the field's AI Prompt (+ example) becomes the runtime instruction handed to the
    // generic "Extract Field (Generic)" skill — so what the analyst edits in the wizard IS what runs.
    if (input && input.action === 'test') {
        data.testOutput = '';
        data.testStatus = '';
        var fieldName = input.testField || '';
        var sampleText = input.testInput || '';
        try {
            if (!sampleText) {
                data.testOutput = '(enter some input text to test)';
            } else {
                var instruction = 'Extract the field "' + fieldName + '". ' + (input.testPrompt || '');
                // Pair Example + Value into a one-shot worked example so the model learns input -> answer.
                if (input.testExample || input.testValue) {
                    instruction += '\n\nWorked example —';
                    if (input.testExample) { instruction += '\nINPUT: ' + input.testExample; }
                    if (input.testValue) { instruction += '\nVALUE: ' + input.testValue; }
                }
                // Skeleton is format-neutral, so the instruction must set the output format.
                instruction += '\n\nReturn ONLY the extracted value as plain text — no field name, no quotes, no JSON. If it is genuinely absent, return an empty string.';
                var gx = new x_nose_nfotc_bsm.GenericFieldExtractor();
                var res = gx.extract(instruction, sampleText);
                data.testStatus = res.status || '';
                data.testOutput = (res.status === 'ok')
                    ? (res.value || '(the model returned an empty value — field not found)')
                    : ('(no value — status: ' + (res.status || 'unknown') + ')');
            }
        } catch (et) {
            data.testOutput = 'error: ' + et;
        }
        return;   // don't fall through to persist; the client keeps its working model
    }

    // ---- Prompt enhancer (custom fields): rewrite the manager's rough AI Prompt via direct Chinou (PromptEnhancer).
    if (input && input.action === 'enhance_prompt') {
        data.enhanceStatus = '';
        data.enhanceText = '';
        try {
            var _pe = new x_nose_nfotc_bsm.PromptEnhancer().enhance(input.enhanceDraft || '', input.enhanceField || '', input.enhanceMode || '');
            data.enhanceStatus = _pe.status || '';
            data.enhanceText = (_pe.status === 'ok') ? (_pe.text || '') : '';
        } catch (ee) {
            data.enhanceStatus = 'error';
        }
        return;   // don't fall through to persist; the client keeps its working model
    }

    // ---- Record-mode run: extract EVERY trade/row from a sample, using all configured fields ----
    // One skill call, one JSON object per row, so multi-trade emails stay aligned per row.
    if (input && input.action === 'run_extract') {
        data.runRows = [];
        data.runKeys = [];
        data.runStatus = '';
        var fields = input.runFields || [];
        var sample = input.runInput || '';
        function slug(s) { return ('' + (s || '')).toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '') || 'field'; }
        try {
            if (!sample) { data.runStatus = 'no_input'; return; }
            if (!fields.length) { data.runStatus = 'no_fields'; return; }
            var keys = [], lines = [], seen = {};
            for (var i = 0; i < fields.length; i++) {
                var f = fields[i] || {};
                var key = slug(f.name); var base = key, n = 2;
                while (seen[key]) { key = base + '_' + (n++); }
                seen[key] = true;
                keys.push({ key: key, label: f.name || key });
                var line = '- ' + key + ': ' + (f.prompt || f.name || key);
                var exParts = [];
                var fexr = f.examples || [];
                for (var xr = 0; xr < fexr.length; xr++) { var evr = fexr[xr]; if (evr && typeof evr === 'object') { evr = evr.value; } if (evr) { exParts.push('"' + evr + '"'); } }
                if (exParts.length) { line += ' (example values: ' + exParts.join(', ') + ')'; }
                else if (f.value) { line += ' (example value: "' + f.value + '")'; }
                lines.push(line);
            }
            var shape = [];
            for (var j = 0; j < keys.length; j++) { shape.push('"' + keys[j].key + '":""'); }
            var instruction =
                'Extract EVERY trade / row present in the TEXT (there may be one row or many — e.g. each line of a table is a row). ' +
                'For EACH row, extract these fields:\n' + lines.join('\n') +
                '\n\nReturn ONLY a JSON array — one object per row, each object exactly {' + shape.join(',') + '}. ' +
                'No markdown, no code fences, no commentary. If a field is absent for a row, use "".';
            var gx = new x_nose_nfotc_bsm.GenericFieldExtractor();
            var res = gx.extractRecords(instruction, sample);
            data.runStatus = res.status;
            data.runKeys = keys;
            data.runRaw = ('' + (res.raw || '')).substring(0, 4000);
            if (res.status === 'ok') {
                var _we = new x_nose_nfotc_bsm.WizardExtractor();   // same deterministic guardrail as the runtime extraction
                var rows = [];
                for (var r = 0; r < res.rows.length; r++) {
                    var obj = res.rows[r] || {}, row = {};
                    for (var k = 0; k < keys.length; k++) {
                        row[keys[k].key] = _we.validateField(keys[k].label, obj[keys[k].key]);
                    }
                    rows.push(row);
                }
                data.runRows = rows;
            }
        } catch (er) {
            data.runStatus = 'error';
            data.runRaw = '' + er;
        }
        return;
    }

    // ---- persist: save-as-draft / publish ----
    if (input && (input.action === 'save_draft' || input.action === 'publish') && input.model) {
        var m = input.model;
        var rec = new GlideRecord('x_nose_nfotc_bsm_wizard');
        var isUpdate = m.id && rec.get(m.id);
        if (!isUpdate) { rec.initialize(); }
        rec.setValue('name', m.name || 'Untitled wizard');
        rec.setValue('description', m.description || '');
        rec.setValue('bu', m.bu || '');
        rec.setValue('sub_bu', m.subBu || '');
        rec.setValue('service', m.service || '');
        rec.setValue('work_driver', m.workDriver || '');
        rec.setValue('activity', m.activity || '');
        rec.setValue('input_format', m.inputFormat || '');
        rec.setValue('ingestion_type', m.ingestionType || '');
        rec.setValue('mailbox', m.mailbox || '');
        rec.setValue('frequency', m.frequency || '');
        // Store the field rows (name + type + AI prompt + example + value + flags) NORMALISED: the server -- not the
        // browser -- decides the persisted shape, so a mandatory field can never be saved as custom / renamed / missing
        // and a custom row can never shadow a catalog field (see _normaliseFields above).
        var sel = _normaliseFields(m.fields || [], _isCsgModel(m.service, m.subBu, m.workDriver));
        rec.setValue('input_fields', JSON.stringify(sel));
        rec.setValue('id_rules', JSON.stringify(m.labels || []));
        rec.setValue('tagging', JSON.stringify(m.tagging || []));
        // Write-back: persist each outcome's ACTION LIST only (drop the transient _add UI field; tolerate legacy {action}).
        var wbOut = [], wbIn = m.writeback || [];
        for (var wbi = 0; wbi < wbIn.length; wbi++) {
            var wbActs = (wbIn[wbi].actions instanceof Array) ? wbIn[wbi].actions : (wbIn[wbi].action ? [wbIn[wbi].action] : []);
            wbOut.push({ scenario: wbIn[wbi].scenario, actions: wbActs });
        }
        rec.setValue('writeback', JSON.stringify(wbOut));
        var t0 = (m.targets && m.targets[0]) || { system: '', map: {} };
        rec.setValue('target_system', t0.system || '');
        rec.setValue('mapping', JSON.stringify(t0.map || {}));
        // Per-driver Compare & Match tolerances -> config_overrides (blank/invalid = inherit system default;
        // preserve any non-tolerance override keys already on the record).
        var _ovOut = {};
        try { _ovOut = JSON.parse(rec.getValue('config_overrides') || '{}') || {}; } catch (eo) { _ovOut = {}; }
        var _mt = m.tolerances || {};
        for (var _ti = 0; _ti < data.cat.tolerances.length; _ti++) {
            var _ck = data.cat.tolerances[_ti].ckey, _mk = data.cat.tolerances[_ti].mkey;
            var _val = ('' + (_mt[_mk] === undefined || _mt[_mk] === null ? '' : _mt[_mk])).trim();
            if (_val === '' || isNaN(parseFloat(_val))) { delete _ovOut[_ck]; } else { _ovOut[_ck] = _val; }
        }
        rec.setValue('config_overrides', JSON.stringify(_ovOut));
        rec.setValue('status', input.action === 'publish' ? 'published' : 'draft');
        rec.setValue('version', m.version || 'v1');
        if (isUpdate) { rec.update(); data.savedId = m.id; } else { data.savedId = '' + rec.insert(); }
        data.saved = true;
        data.savedAction = input.action;
        // (Wizard lifecycle is intentionally NOT written to the cashflow audit trail.)
    }
})();
