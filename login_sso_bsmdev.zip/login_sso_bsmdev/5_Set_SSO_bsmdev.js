/**
 * STEP B - enable SSO auto-redirect for the /nfotcbsm login on THIS instance. Run ONCE per instance.
 * Scripts - Background, Application = "NexAI OTC BSM" (x_nose_nfotc_bsm), sandbox unchecked.
 * Paste the IdP sys_id from STEP A below. (Do NOT run on eval - it has no SSO; leave the form there.)
 */
(function () {
    var IDP_SYS_ID = '<PASTE IdP sys_id FROM STEP A>';
    if (IDP_SYS_ID.indexOf('<') === 0) { gs.error('[SSO-CFG] paste the IdP sys_id into IDP_SYS_ID first'); return; }
    gs.setProperty('x_nose_nfotc_bsm.sso_idp', IDP_SYS_ID);
    gs.setProperty('x_nose_nfotc_bsm.sso_auto', 'true');   // 'false' = show the form with a working SSO button instead
    gs.info('[SSO-CFG] sso_idp=' + gs.getProperty('x_nose_nfotc_bsm.sso_idp') + '  sso_auto=' + gs.getProperty('x_nose_nfotc_bsm.sso_auto'));
})();
