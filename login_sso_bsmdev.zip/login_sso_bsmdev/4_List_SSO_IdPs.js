/**
 * STEP A - find the Identity Provider sys_id on THIS instance (bsmdev).
 * Run in Scripts - Background, Application = GLOBAL, sandbox unchecked. Copy the sys_id of the ACTIVE SAML IdP.
 */
(function () {
    var g = new GlideRecord('sso_properties');   // Multi-Provider SSO > Identity Providers
    g.query();
    var n = 0;
    while (g.next()) {
        n++;
        gs.info('[SSO-IDP] ' + g.getValue('name') + '  sys_id=' + g.getUniqueValue() +
            '  active=' + g.getValue('active') + '  default=' + g.getValue('default'));
    }
    if (!n) { gs.info('[SSO-IDP] no Identity Providers found in sso_properties'); }
})();
