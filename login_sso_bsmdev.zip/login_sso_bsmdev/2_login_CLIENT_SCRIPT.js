/**
 * OTC console login - custom branded sign-in for the /nfotcbsm Service Portal.
 * Authenticates through the same endpoint the OOTB Service Portal login widget uses
 * (view_form.login), so it is a real, working login (not a mock). On success it
 * redirects to the landing (/nfotcbsm?id=bsm_work_drivers).
 *
 * SSO-aware: if the server reports an SSO deep-link (an Identity Provider is configured on this
 * instance) the visitor is sent to the platform SSO login instead of the form - automatically when
 * sso_auto is on, or via the "Log in with SSO" button when it is off.
 */
function controller($scope, $http, $window, spUtil) {
    var c = this;
    c.username = '';
    c.password = '';
    c.message = '';
    c.busy = false;

    var HOME = '/nfotcbsm?id=bsm_work_drivers';

    // 1) Already authenticated (SSO session established at the instance layer) -> straight to the landing.
    if (c.data && c.data.authed) {
        $window.location = c.data.redirect || HOME;
        return;
    }

    // 2) An IdP is configured and auto mode is on -> go to the platform SSO login immediately. SSO
    //    completes there and returns to sysparm_goto_url (the landing), where case 1 then applies.
    if (c.data && c.data.ssoUrl && c.data.ssoAuto) {
        $window.location = c.data.ssoUrl;
        return;
    }

    // "Log in with SSO" button - live when an IdP is configured; otherwise it explains itself.
    c.ssoLogin = function () {
        if (c.data && c.data.ssoUrl) { $window.location = c.data.ssoUrl; return; }
        c.message = 'SSO is not configured on this instance. Please sign in with your username and password.';
    };

    // 3) Username / password sign-in (non-SSO instances, or SSO with sso_auto off).
    c.login = function (username, password) {
        if (!username || !password) {
            c.message = 'Please enter your username and password.';
            return;
        }
        c.busy = true;
        c.message = '';

        var url = spUtil.getURL({ sysparm_type: 'view_form.login' });
        var body = {
            sysparm_type: 'login',
            'ni.nolog.user_password': true,
            remember_me: true,
            user_name: username,
            user_password: password,
            get_redirect_url: true,
            is_direct_redirect: true,
            sysparm_goto_url: HOME,
            cert_login: false
        };
        var enc = Object.keys(body).map(function (k) {
            return encodeURIComponent(k) + '=' + encodeURIComponent(body[k]);
        }).join('&');

        $http({
            method: 'post',
            url: url,
            data: enc,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }).then(function (res) {
            c.busy = false;
            var d = res.data || {};
            if (d.status === 'success') {
                $window.location = d.redirect_url || HOME;
            } else if (d.status === 'mfa_code_required') {
                $window.location = '/validate_multifactor_auth_code.do';
            } else {
                c.message = d.message || 'Invalid username or password.';
                c.password = '';
            }
        }, function () {
            c.busy = false;
            c.message = 'Sign-in failed. Please try again.';
        });
    };
}
