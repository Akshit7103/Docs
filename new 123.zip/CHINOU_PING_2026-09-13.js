/**
 * CHINOU PING — proves whether the "LLMError: 'list' object has no attribute 'get'" is CENTRAL (Chinou backend)
 * or instance-specific. Run in Scripts - Background (Global scope is fine), sandbox UNCHECKED:
 *   1) on EVAL  (nomuraevalinstancegenaipov)
 *   2) on Nomura BSMDEV (nomurabsmdev)
 * Same error on BOTH  => central Chinou fault (raise with the AI CoE; nothing to fix on our side).
 * Works on bsmdev but not eval => something eval-specific (shared Chinou config on eval was changed).
 */
(function () {
    var t0 = new GlideDateTime().getNumericValue();
    var r = new global.ChinouClient().invoke('Reply with the single word OK and nothing else.');
    var ms = new GlideDateTime().getNumericValue() - t0;
    gs.info('[CHINOU-PING] success=' + (r && r.success) + ' status=' + (r && r.status) + ' model=' + (r && r.model) +
        ' ms=' + ms + ' blocked=' + (r && r.blocked) + ' error=' + ((r && r.error) || '(none)') +
        ' response=' + ('' + ((r && r.response) || '')).substring(0, 80));
})();
